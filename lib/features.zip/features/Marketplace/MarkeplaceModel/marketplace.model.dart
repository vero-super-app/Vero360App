// lib/models/marketplace.model.dart
// Remove the toCartModel methods or comment them out for now
import 'dart:convert';

class MarketplaceItem {
  final String name;
  final double price;
  final String image;
  final String? description;
  final String location;
  final bool isActive;
  final String? category;
  final List<String>? gallery;
  final List<String>? videos;
  final String? sellerUserId;
  final String? merchantId;
  final String? merchantName;
  final String? serviceType;
  final double? latitude;
  final double? longitude;

  MarketplaceItem({
    required this.name,
    required this.price,
    required this.image,
    required this.location,
    this.description,
    this.isActive = true,
    this.category,
    this.gallery,
    this.videos,
    this.sellerUserId,
    this.merchantId,
    this.merchantName,
    this.serviceType,
    this.latitude,
    this.longitude,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'price': price,
    'image': image,
    'location': location,
    if (description != null) 'description': description,
    'isActive': isActive,
    if (category != null) 'category': category,
    if (gallery != null && gallery!.isNotEmpty) 'gallery': gallery,
    if (videos != null && videos!.isNotEmpty) 'videos': videos,
    if (sellerUserId != null) 'sellerUserId': sellerUserId,
    if (merchantId != null) 'merchantId': merchantId,
    if (merchantName != null) 'merchantName': merchantName,
    if (serviceType != null) 'serviceType': serviceType,
    if (latitude != null) 'latitude': latitude,
    if (longitude != null) 'longitude': longitude,
  };

  bool get hasValidMerchantInfo => 
      merchantId != null && 
      merchantId!.isNotEmpty && 
      merchantId != 'unknown' &&
      merchantName != null &&
      merchantName!.isNotEmpty &&
      merchantName != 'Unknown Merchant';

  // Comment out or remove toCartModel for now to fix compilation
  /*
  CartModel toCartModel({required String userId, required int itemId}) {
    return CartModel(
      userId: userId,
      item: itemId,
      quantity: 1,
      image: image,
      name: name,
      price: price,
      description: description ?? '',
      merchantId: merchantId ?? 'unknown',
      merchantName: merchantName ?? 'Unknown Merchant',
      serviceType: serviceType ?? 'marketplace',
    );
  }
  */
}

class MarketplaceDetailModel {
  final int id;
  final String name;
  final String image;
  final double price;
  final String description;
  final String location;
  final String? comment;
  final String? category;
  final List<String> gallery;
  final List<String> videos;
  final String? sellerBusinessName;
  final String? sellerOpeningHours;
  final String? sellerStatus;
  final String? sellerBusinessDescription;
  final double? sellerRating;
  final String? sellerLogoUrl;
  final String? serviceProviderId;
  final String? sellerUserId;
  final String? merchantId;
  final String? merchantName;
  final int? merchantBackendId;
  final String? firestoreDocId;
  final String? serviceType;
  final DateTime? createdAt;
  final double? latitude;
  final double? longitude;
  /// Available units the seller has. Null = legacy / uncapped (buyer limited to 99).
  final int? stockQuantity;

  MarketplaceDetailModel({
    required this.id,
    required this.name,
    required this.image,
    required this.price,
    required this.description,
    required this.location,
    this.comment,
    this.category,
    this.gallery = const [],
    this.videos = const [],
    this.sellerBusinessName,
    this.sellerOpeningHours,
    this.sellerStatus,
    this.sellerBusinessDescription,
    this.sellerRating,
    this.sellerLogoUrl,
    this.serviceProviderId,
    this.sellerUserId,
    this.merchantId,
    this.merchantName,
    this.merchantBackendId,
    this.firestoreDocId,
    this.serviceType,
    this.createdAt,
    this.latitude,
    this.longitude,
    this.stockQuantity,
    int? backendItemId,
  });

  bool get isOutOfStock => stockQuantity != null && stockQuantity! <= 0;

  int get maxOrderQty {
    if (stockQuantity == null) return 99;
    return stockQuantity!.clamp(0, 99999);
  }

  factory MarketplaceDetailModel.fromJson(Map<String, dynamic> j) {
    List<String> arr(dynamic v) {
      if (v is List) {
        return v
            .map((e) => '$e'.trim())
            .where((s) => s.isNotEmpty)
            .toList();
      }
      if (v is String) {
        final raw = v.trim();
        if (raw.isEmpty) return const <String>[];
        try {
          final decoded = jsonDecode(raw);
          if (decoded is List) {
            return decoded
                .map((e) => '$e'.trim())
                .where((s) => s.isNotEmpty)
                .toList();
          }
        } catch (_) {
          // Fallback for comma-separated values.
        }
        return raw
            .split(',')
            .map((e) => e.trim())
            .where((s) => s.isNotEmpty)
            .toList();
      }
      return const <String>[];
    }
    double toDoubleVal(dynamic v) => (v is num) ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    double? optDouble(dynamic v) {
      if (v == null) return null;
      if (v is num) return v.toDouble();
      return double.tryParse(v.toString());
    }

    final String? sellerUserId =
        (j['sellerUserId'] ?? j['ownerId'])?.toString();

    final galleryMerged = () {
      final a = arr(j['gallery']);
      final b = arr(j['galleryUrls']);
      final seen = <String>{};
      final out = <String>[];
      for (final s in [...a, ...b]) {
        if (s.isEmpty || seen.contains(s)) continue;
        seen.add(s);
        out.add(s);
      }
      return out;
    }();

    return MarketplaceDetailModel(
      id: j['id'] ?? 0,
      name: '${j['name'] ?? ''}',
      image: '${j['image'] ?? j['imageUrl'] ?? j['photo'] ?? j['picture'] ?? ''}',
      price: toDoubleVal(j['price'] ?? 0),
      description: '${j['description'] ?? ''}',
      location: '${j['location'] ?? ''}',
      comment: j['comment']?.toString(),
      category: j['category']?.toString(),
      gallery: galleryMerged,
      videos: arr(j['videos']),
      sellerBusinessName: j['sellerBusinessName']?.toString(),
      sellerOpeningHours: j['sellerOpeningHours']?.toString(),
      sellerStatus: j['sellerStatus']?.toString(),
      sellerBusinessDescription: j['sellerBusinessDescription']?.toString(),
      sellerRating: (j['sellerRating'] is num)
          ? (j['sellerRating'] as num).toDouble()
          : double.tryParse('${j['sellerRating']}'),
      sellerLogoUrl: j['sellerLogoUrl']?.toString(),
      serviceProviderId: j['serviceProviderId']?.toString(),
      sellerUserId: sellerUserId,
      merchantId: j['merchantId']?.toString(),
      merchantName: j['merchantName']?.toString(),
      merchantBackendId: () {
        final raw = j['merchantBackendId'] ?? j['backendUserId'];
        if (raw is num) return raw.toInt();
        return int.tryParse('${raw ?? ''}');
      }(),
      serviceType: j['serviceType']?.toString() ?? 'marketplace',
      createdAt: j['createdAt'] != null ? DateTime.tryParse(j['createdAt'].toString()) : null,
      latitude: optDouble(j['latitude'] ?? j['lat']),
      longitude: optDouble(j['longitude'] ?? j['lng']),
      stockQuantity: () {
        final raw = j['stockQuantity'] ?? j['quantity'] ?? j['stock'];
        if (raw is num) return raw.toInt();
        return int.tryParse('${raw ?? ''}');
      }(),
    );
  }


}