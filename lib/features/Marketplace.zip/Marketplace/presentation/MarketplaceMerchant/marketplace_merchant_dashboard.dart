import 'dart:async';
import 'dart:convert';
import 'dart:io' show File;
import 'dart:math';
import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart' show kIsWeb, kDebugMode, compute;
import 'package:flutter/material.dart';
import 'package:vero360_app/GernalServices/buyer_commission.dart';
import 'package:vero360_app/widgets/merchant_commission_guide.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart' show FirebaseException;
import 'package:firebase_storage/firebase_storage.dart';

import 'package:crypto/crypto.dart' show sha256;

import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:mime/mime.dart';

import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import 'package:url_launcher/url_launcher.dart';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart' show MediaType;
import 'package:vero360_app/features/Marketplace/presentation/widgets/PostlatestArrival.dart';
import 'package:vero360_app/widgets/vero_coin_icon_button.dart';
import 'package:vero360_app/features/Promotions/presentation/Postpromotion.dart';
import 'package:vero360_app/features/Marketplace/presentation/pages/shop_pictures_page.dart';
import 'package:vero360_app/config/api_config.dart';
import 'package:vero360_app/features/Marketplace/MarkeplaceModel/marketplace_time.dart';
import 'package:vero360_app/features/Marketplace/MarkeplaceService/marketplace.service.dart';
import 'package:vero360_app/features/Marketplace/MarkeplaceService/marketplace_moderation.dart';
import 'package:vero360_app/utils/description_contact_mask.dart';
import 'package:vero360_app/features/Marketplace/MarkeplaceService/marketplace_promote_service.dart';

import 'package:vero360_app/GernalServices/marketplace_stock_reminder_service.dart';
import 'package:vero360_app/features/Marketplace/MarkeplaceService/merchant_seller_loader.dart';
import 'package:vero360_app/features/Marketplace/MarkeplaceService/merchant_review_id_resolver.dart';
import 'package:vero360_app/GernalServices/profile_photo_cache.dart';
import 'package:vero360_app/features/Cart/CartService/cart_services.dart';
import 'package:vero360_app/Gernalproviders/cart_service_provider.dart';
import 'package:vero360_app/widgets/vero_thumb_image.dart';
import 'package:vero360_app/settings/Settings.dart';
import 'package:vero360_app/utils/toasthelper.dart';
import 'package:vero360_app/utils/formatters.dart';
// Add login screen import (using your correct path)
import 'package:vero360_app/features/Auth/AuthServices/auth_handler.dart';
import 'package:vero360_app/features/Auth/AuthPresenter/kyc_verification_screen.dart';
import 'package:vero360_app/utils/kyc_gate.dart';
import 'package:vero360_app/features/BottomnvarBars/BottomNavbar.dart'
    show veroFloatingNavClearance;

import 'package:vero360_app/Home/homepage.dart';
import 'package:vero360_app/features/Marketplace/presentation/pages/main_marketPlace.dart';
import 'package:vero360_app/features/Cart/CartPresentaztion/pages/cartpage.dart';
import 'package:vero360_app/GernalScreens/chat_list_page.dart';
import 'package:vero360_app/features/Marketplace/presentation/MarketplaceMerchant/merchant_wallet.dart';
import 'package:vero360_app/utils/app_wallet_pin.dart';

import 'package:vero360_app/Home/myorders.dart';
import 'package:vero360_app/Home/post_story_page.dart';
import 'package:vero360_app/Home/story_ring_widget.dart';
import 'package:vero360_app/GeneralPages/ToRefund.dart';
import 'package:vero360_app/GeneralPages/Toreceive.dart';
import 'package:vero360_app/GeneralPages/Toship.dart';
import 'package:vero360_app/Gernalproviders/notification_store.dart';
import 'package:vero360_app/GernalServices/order_service.dart';
import 'package:vero360_app/GeneralModels/order_model.dart';
import 'package:vero360_app/features/ride_share/presentation/pages/ride_history_screen.dart';
import 'package:vero360_app/features/Restraurants/RestraurantPresenter/RestraurantMerchants/food_business_location_picker.dart';
import 'package:vero360_app/GeneralModels/place_model.dart';
import 'package:vero360_app/GernalServices/google_places_service.dart';

import 'package:intl/intl.dart'; // G?? NEW

// ----------------- G?? PRICE FORMAT HELPERS (MWK with commas) -----------------
final NumberFormat _mwk0Fmt =
    NumberFormat.currency(locale: 'en_US', symbol: 'MWK ', decimalDigits: 0);
final NumberFormat _mwk2Fmt =
    NumberFormat.currency(locale: 'en_US', symbol: 'MWK ', decimalDigits: 2);

num _asNum(dynamic v) {
  if (v == null) return 0;
  if (v is num) return v;
  final s = v.toString().replaceAll(',', '').trim();
  return num.tryParse(s) ?? 0;
}

String mwk0(dynamic v) => _mwk0Fmt.format(_asNum(v)); // MWK 12,500

/// Customer price on My Items: the amount the merchant entered plus commission.
String mwkBuyer(dynamic v) =>
    mwk0(BuyerCommission.buyerFacing(_asNum(v)));
String mwk2(dynamic v) => _mwk2Fmt.format(_asNum(v)); // MWK 12,500.00
// ---------------------------------------------------------------------------

/// G?Your ItemsG? / G?My ItemsG? grids: taller cells on narrow screens + large text scale
/// so [_ModernItemMiniCard] / [_ItemCard] never bottom-overflow inside the cell.
SliverGridDelegate _merchantItemsGridDelegate(BuildContext context) {
  final w = MediaQuery.sizeOf(context).width;
  final textScale =
      MediaQuery.textScalerOf(context).clamp(maxScaleFactor: 1.8).scale(14) /
          14.0;

  // Lower ratio = taller cells (room for status, promote, actions, reject reason).
  var ratio = 0.62;
  var spacing = 12.0;
  if (w < 330) {
    ratio = 0.40;
    spacing = 8;
  } else if (w < 360) {
    ratio = 0.44;
    spacing = 8;
  } else if (w < 400) {
    ratio = 0.50;
    spacing = 10;
  } else if (w < 430) {
    ratio = 0.56;
    spacing = 10;
  }

  if (textScale > 1.08) {
    ratio -= 0.06 * ((textScale - 1.0) * 2).clamp(0.0, 1.0);
  }
  ratio = ratio.clamp(0.40, 0.72);

  return SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2,
    crossAxisSpacing: spacing,
    mainAxisSpacing: spacing,
    childAspectRatio: ratio,
  );
}

/// Filters out Firebase identifiers (e.g. +firebase_xxx) so we show real phone numbers only.
String _sanitizePhone(String s) {
  final t = (s ?? '').trim();
  if (t.isEmpty) return '';
  if (t.toLowerCase().startsWith('+firebase_') ||
      t.toLowerCase().contains('firebase_')) {
    return '';
  }
  return t;
}

class LocalMedia {
  final Uint8List bytes;
  final String filename;
  final String? mime;
  final bool isVideo;
  final String? filePath;
  const LocalMedia({
    required this.bytes,
    required this.filename,
    this.mime,
    this.isVideo = false,
    this.filePath,
  });
}

class MarketplaceMerchantDashboard extends StatefulWidget {
  final String email;
  /// Firebase uid this shop dashboard is bound to (single source of truth).
  final String? merchantUid;
  /// When true, this dashboard is shown as a tab inside the main app bottom nav;
  /// hide our own bottom nav to avoid two overlapping bars.
  final bool embeddedInMainNav;
  /// Inner TabBar index: 0 Dashboard, 1 Add Item, 2 My Items, 3 Profile.
  final int initialInnerTab;

  const MarketplaceMerchantDashboard({
    super.key,
    required this.email,
    required void Function() onBackToHomeTab,
    this.merchantUid,
    this.embeddedInMainNav = false,
    this.initialInnerTab = 0,
  });

  /// Drop My Items memory on logout / account switch.
  static void clearSessionCaches() {
    _MarketplaceMerchantDashboardState.clearSessionCaches();
  }

  @override
  State<MarketplaceMerchantDashboard> createState() =>
      _MarketplaceMerchantDashboardState();
}

class _MarketplaceMerchantDashboardState
    extends State<MarketplaceMerchantDashboard> with TickerProviderStateMixin {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final OrderService _orderService = OrderService();

  // G?? Use CartService singleton from provider
  final CartService _cartService = CartServiceProvider.getInstance();

  final _picker = ImagePicker();

  // Form controllers (create)
  final _name = TextEditingController();
  final _price = TextEditingController();
  final _location = TextEditingController();
  final _desc = TextEditingController();
  final _stock = TextEditingController(text: '1');
  int _stockQty = 1;
  bool _addItemCommissionShown = false;
  static bool _commissionGuideShownThisInstall = false;
  static const String _commissionGuidePrefKey =
      'marketplace_price_commission_guide_shown_v1';
  final FocusNode _priceFocus = FocusNode();

  late TabController _marketplaceTabs;

  // Create form state
  bool _isActive = true;
  bool _submitting = false;
  /// Share to Vero360 Facebook Page when listing goes live (default on).
  bool _postToFacebook = true;

  LocalMedia? _cover;

  // G?? multi-photos for posting
  static const int _maxGalleryPhotos = 5;
  static const int _maxVideos = 2;
  static const int _maxVideoBytes = 40 * 1024 * 1024;
  final List<LocalMedia> _gallery = <LocalMedia>[];
  final List<LocalMedia> _videos = <LocalMedia>[];

  static const List<String> _kCategories = <String>[
    'drinks',
    'electronics',
    'clothes',
    'shoes',
    'other',
  ];
  String? _category = 'other';

  // Items
  List<Map<String, dynamic>> _items = [];
  bool _loadingItems = true;
  bool _busyRow = false;

  /// Instant My Items cache (survives tab switches / reopen in-session).
  static final Map<String, List<Map<String, dynamic>>> _itemsMemoryByUid =
      <String, List<Map<String, dynamic>>>{};

  static void clearSessionCaches() {
    _itemsMemoryByUid.clear();
  }

  static const String _prefsItemsCachePrefix = 'merchant_my_items_cache_v1_';
  static const String _prefsEarningsCachePrefix = 'merchant_earnings_cache_v2_';

  // Filters (My Items)
  String _searchQuery = '';
  String _filterCategory = 'all'; // all | food | ...
  String _filterStatus = 'all'; // all | active | inactive | pending | rejected

  // Dashboard state
  /// Real sold orders (confirmed+paid or delivered) from OrderService for Recent Sales.
  List<OrderItem> _recentSalesOrders = [];
  final TextEditingController _recentSalesSearchController = TextEditingController();
  final FocusNode _recentSalesSearchFocus = FocusNode();
  bool _isLoading = true;
  bool _initialLoadComplete = false;

  String _uid = '';
  String _businessName = ''; // resolved name for UI
  double _walletBalance = 0;

  // Stats
  int _totalItems = 0;
  int _activeItems = 0;
  int _soldItems = 0;
  double _totalEarnings = 0;
  /// Fresh escrow total from this session. Refunds can lower this; the saved
  /// cache must not keep the old higher number.
  double? _freshEscrowEarnings;
  double _rating = 0.0;
  String _status = 'pending';

  /// Didit KYC: verified | pending | rejected | (empty = not started)
  String _kycStatus = '';
  String _kycRejectionReason = '';

  // Merchant profile details
  String _merchantEmail = 'No Email';
  String _merchantPhone = 'No Phone';
  String _merchantProfileUrl = '';
  /// Short public blurb shown on shop + product details (max 120 chars).
  String _businessDescription = '';
  /// Public shop pickup / storefront location.
  String _businessLocation = '';
  double? _businessLat;
  double? _businessLng;
  /// Local disk path from [ProfilePhotoCache] for instant avatar display.
  String? _localPhotoPath;

  TimeOfDay? _openTime;
  TimeOfDay? _closeTime;
  /// Dart [DateTime.weekday] values: 1 = Mon G? 7 = Sun. Empty = every day.
  Set<int> _openDays = {};

  bool _loadingMe = false;
  bool _profileUploading = false;
  bool _profileBusy = false;

  Timer? _ticker;

  // G?? prevent periodic refresh while an edit sheet is open (stops random crashes)
  bool _sheetOpen = false;

  // First-time merchant guide (show once after login, then persist as done)
  static const String _kMerchantGuidePrefKey = 'marketplace_merchant_guide_v1_done';
  static const String _kMerchantGuideShowOnNextOpenKey = 'marketplace_merchant_guide_show_on_next_open';
  static const String _kBusinessDescPrefKey = 'merchant_business_description';
  static const String _kShopHoursPrefKey = 'merchant_shop_opening_hours';
  static const String _kShopDaysPrefKey = 'merchant_shop_opening_days';
  static const String _kBusinessLocationPrefKey = 'merchant_business_location';
  static const String _kBusinessLatPrefKey = 'merchant_business_lat';
  static const String _kBusinessLngPrefKey = 'merchant_business_lng';
  static const int _kBusinessDescMaxLen = 120;
  bool _showMerchantGuide = false;
  int _merchantGuideStep = 0;
  bool _merchantGuideCheckScheduled = false;

  // Brand
  static const Color _brandOrange = Color(0xFFFF8A00);
  static const Color _brandNavy = Color(0xFF16284C);
  static const Color _dialogFieldFill = Color(0xFFF4F6FA);

  InputDecoration _walletPinFieldDecoration(String hint) {
    final r = BorderRadius.circular(12);
    return InputDecoration(
      hintText: hint,
      counterText: '',
      isDense: true,
      filled: true,
      fillColor: _dialogFieldFill,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(borderRadius: r),
      enabledBorder: OutlineInputBorder(
        borderRadius: r,
        borderSide: BorderSide(color: Colors.grey.shade200),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: r,
        borderSide: const BorderSide(color: _brandOrange, width: 2),
      ),
    );
  }

  Widget _walletPinDialogHeader({
    required IconData icon,
    required String title,
    String? subtitle,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFF8A00), Color(0xFFFFA64D)],
        ),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                    letterSpacing: -0.2,
                    height: 1.1,
                  ),
                ),
                if (subtitle != null && subtitle.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.92),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      height: 1.2,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _walletPinDialogShell({
    required BuildContext context,
    required Widget header,
    required Widget body,
    required Widget footer,
  }) {
    final mq = MediaQuery.of(context);
    final kb = mq.viewInsets.bottom;
    final usable = mq.size.height - kb;
    final maxHeight =
        usable > 200 ? (usable - 24).clamp(200.0, usable) : usable.clamp(120.0, usable);

    return AnimatedPadding(
      padding: EdgeInsets.only(bottom: kb),
      duration: const Duration(milliseconds: 100),
      curve: Curves.easeOut,
      child: Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 340,
            maxHeight: maxHeight,
          ),
          child: Material(
            color: Colors.white,
            elevation: 18,
            shadowColor: Colors.black.withValues(alpha: 0.2),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            clipBehavior: Clip.antiAlias,
            child: SingleChildScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  header,
                  body,
                  const Divider(height: 1, thickness: 1),
                  footer,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ----------------- Wallet lock (PIN) -----------------
  DateTime? _walletUnlockedUntil;
  static const Duration _walletUnlockDuration = Duration(minutes: 5);

  bool get _walletUnlockedNow {
    final until = _walletUnlockedUntil;
    if (until == null) return false;
    return DateTime.now().isBefore(until);
  }

  /// Display phone; filters out Firebase identifiers so we never show +firebase_xxx.
  String get _displayMerchantPhone {
    final s = _sanitizePhone(_merchantPhone);
    return s.isEmpty ? 'No Phone' : _merchantPhone;
  }

  void _toastOk(String msg) {
    ToastHelper.showCustomToast(
      context,
      msg,
      isSuccess: true,
      errorMessage: '',
    );
  }

  void _toastErr(String msg) {
    ToastHelper.showCustomToast(
      context,
      msg,
      isSuccess: false,
      errorMessage: '',
    );
  }

  Random _safeRandom() {
    try {
      return Random.secure();
    } catch (_) {
      return Random();
    }
  }

  String _randomSalt([int len = 16]) {
    const chars =
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final r = _safeRandom();
    return List.generate(len, (_) => chars[r.nextInt(chars.length)]).join();
  }

  String _hashPin(String pin, String salt) {
    final bytes = utf8.encode('$pin::$salt');
    return sha256.convert(bytes).toString();
  }

  Future<bool> _ensureAppPinExists() async {
    final sp = await SharedPreferences.getInstance();
    final existingHash = sp.getString('app_pin_hash');
    final existingSalt = sp.getString('app_pin_salt');

    if (existingHash != null &&
        existingHash.trim().isNotEmpty &&
        existingSalt != null &&
        existingSalt.trim().isNotEmpty) {
      return true;
    }

    final pin = await _showSetPinDialog();
    if (pin == null) return false;

    final salt = _randomSalt();
    final hash = _hashPin(pin, salt);

    await sp.setString('app_pin_salt', salt);
    await sp.setString('app_pin_hash', hash);

    if (!mounted) return true;
    _toastOk('Wallet password set');
    return true;
  }

  Future<bool> _unlockWalletWithPin() async {
    if (_walletUnlockedNow) return true;

    final ok = await AppWalletPin.verifyWalletUnlock(context);
    if (!ok || !mounted) return false;

    setState(() {
      _walletUnlockedUntil = DateTime.now().add(_walletUnlockDuration);
    });
    return true;
  }

  Future<String?> _showEnterPinDialog() async {
    final controller = TextEditingController();
    String? shortPinHint;

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setLocal) {
          return _walletPinDialogShell(
            context: ctx,
            header: _walletPinDialogHeader(
              icon: Icons.account_balance_wallet_rounded,
              title: 'Unlock wallet',
              subtitle: 'Enter your 4G??6 digit PIN.',
            ),
            body: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: controller,
                    autofocus: true,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    onChanged: (_) {
                      if (shortPinHint != null) {
                        setLocal(() => shortPinHint = null);
                      }
                    },
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                    decoration: _walletPinFieldDecoration('Wallet PIN (4G??6 digits)'),
                  ),
                  if (shortPinHint != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      shortPinHint!,
                      style: TextStyle(
                        color: _brandNavy.withValues(alpha: 0.9),
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            footer: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 14),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () =>
                          Navigator.of(dialogContext).pop(null),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        side: BorderSide(color: Colors.grey.shade300),
                      ),
                      child: Text(
                        'Cancel',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.grey.shade800,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed: () {
                        final pin = controller.text.trim();
                        if (pin.length < 4) {
                          setLocal(() => shortPinHint =
                              'Enter at least 4 digits.');
                          return;
                        }
                        Navigator.of(dialogContext).pop(pin);
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: _brandOrange,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                      child: const Text(
                        'Unlock',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<String?> _showSetPinDialog() async {
    final p1 = TextEditingController();
    final p2 = TextEditingController();
    String? err;

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setLocal) {
          return _walletPinDialogShell(
            context: ctx,
            header: _walletPinDialogHeader(
              icon: Icons.pin_rounded,
              title: 'Set wallet PIN',
              subtitle: 'Create a 4G??6 digit PIN.',
            ),
            body: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: p1,
                    autofocus: true,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    onChanged: (_) {
                      if (err != null) {
                        setLocal(() => err = null);
                      }
                    },
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                    decoration: _walletPinFieldDecoration('New PIN (4G??6 digits)'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: p2,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    onChanged: (_) {
                      if (err != null) {
                        setLocal(() => err = null);
                      }
                    },
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                    decoration: _walletPinFieldDecoration('Confirm PIN'),
                  ),
                  if (err != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      err!,
                      style: const TextStyle(
                        color: Color(0xFFB71C1C),
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            footer: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 14),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () =>
                          Navigator.of(dialogContext).pop(null),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        side: BorderSide(color: Colors.grey.shade300),
                      ),
                      child: Text(
                        'Cancel',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.grey.shade800,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed: () {
                        final a = p1.text.trim();
                        final b = p2.text.trim();

                        if (a.length < 4) {
                          setLocal(
                              () => err = 'PIN must be at least 4 digits.');
                          return;
                        }
                        if (a != b) {
                          setLocal(() => err = 'PINs do not match.');
                          return;
                        }
                        Navigator.of(dialogContext).pop(a);
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: _brandOrange,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                      child: const Text(
                        'Save PIN',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    // Standalone push (e.g. chat “finish business profile”) must show dashboard
    // content (index 4), not the merchant shell Home tab (index 0).
    if (widget.embeddedInMainNav || widget.initialInnerTab > 0) {
      _selectedIndex = 4;
    }
    final startTab = widget.initialInnerTab.clamp(0, 3);
    _priceFocus.addListener(_onPriceFieldFocused);
    unawaited(_rememberCommissionGuideIfAlreadyShown());
    _marketplaceTabs = TabController(
      length: 4,
      vsync: this,
      initialIndex: startTab,
    );
    _marketplaceTabs.addListener(() {
      if (_marketplaceTabs.indexIsChanging) return;
      // My Items tab: ensure cached list is visible immediately.
      if (_marketplaceTabs.index == 2 && _items.isEmpty) {
        _hydrateItemsFromLocalCache();
        if (_items.isEmpty) {
          unawaited(_hydrateItemsFromPrefsCache());
        } else if (mounted) {
          setState(() => _loadingItems = false);
        }
        unawaited(_loadItems(showLoading: false));
      }
    });

    final pinned = (widget.merchantUid ?? '').trim();
    _uid = pinned.isNotEmpty
        ? pinned
        : (_auth.currentUser?.uid ?? '');

    // Instant My Items from memory/prefs before any network.
    _hydrateItemsFromLocalCache();

    // 1) Instant UI from Auth + prefs (no network).
    _hydrateFromFirebaseAuth();
    unawaited(_bootstrapFast());

    // 2) Items + wallet ASAP (cache-first). Don't flash skeleton if cache hit.
    unawaited(_loadItems(showLoading: _items.isEmpty));
    unawaited(_loadWalletBalance());
    unawaited(_loadOrderStats());

    // 3) Heavier network work after first frame G?? don't block skeleton exit.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      unawaited(_loadMerchantData());
      unawaited(_fetchCurrentUserMe());
      unawaited(_pullPhoneAndProfileFromFirestore());
      unawaited(_loadKycStatus());
      unawaited(_ensureBusinessName());
      // Backfill can rewrite many docs G?? defer so dashboard opens fast.
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (!mounted) return;
        unawaited(_syncBackendUserIdToFirestore());
        unawaited(
          MerchantReviewIdResolver.ensureCurrentUserNestMerchantRole(
            merchantService: 'marketplace',
          ),
        );
      });
    });

    _startPeriodicUpdates();
  }

  /// Prefs + clear loading shell without waiting on APIs.
  Future<void> _bootstrapFast() async {
    await _loadMerchantProfileFromPrefs();
    await _hydrateEarningsFromPrefs();
    // Disk cache may be ready after prefs G?? apply if memory was empty.
    if (_items.isEmpty) {
      await _hydrateItemsFromPrefsCache();
    }
    if (!mounted) return;
    // Show dashboard chrome immediately; sections fill in as data arrives.
    setState(() {
      _isLoading = false;
      _initialLoadComplete = true;
      if (_items.isNotEmpty) _loadingItems = false;
    });

    final mid = (_auth.currentUser?.uid ?? _uid).trim();
    if (mid.isNotEmpty) {
      unawaited(
        MarketplaceStockReminderService.nudgeActiveOutOfStockListings(
          merchantUid: mid,
        ),
      );
    }
  }

  void _hydrateItemsFromLocalCache() {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) return;
    final mem = _itemsMemoryByUid[uid];
    if (mem == null || mem.isEmpty) return;
    _items = mem.map((e) => Map<String, dynamic>.from(e)).toList();
    _totalItems = _items.length;
    _activeItems = _items.where(_countsAsActiveListing).length;
    _loadingItems = false;
  }

  Future<void> _hydrateItemsFromPrefsCache() async {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('$_prefsItemsCachePrefix$uid');
      if (raw == null || raw.isEmpty) return;
      final decoded = jsonDecode(raw);
      if (decoded is! List) return;
      final list = <Map<String, dynamic>>[];
      for (final e in decoded) {
        if (e is Map) {
          list.add(Map<String, dynamic>.from(e));
        }
      }
      if (list.isEmpty) return;
      _itemsMemoryByUid[uid] =
          list.map((e) => Map<String, dynamic>.from(e)).toList();
      if (!mounted) return;
      setState(() {
        _items = list;
        _totalItems = list.length;
        _activeItems = list.where(_countsAsActiveListing).length;
        _loadingItems = false;
      });
    } catch (_) {}
  }

  static Object? _jsonSafe(Object? v) {
    if (v is Timestamp) return v.toDate().toIso8601String();
    if (v is DateTime) return v.toIso8601String();
    if (v is GeoPoint) return {'latitude': v.latitude, 'longitude': v.longitude};
    if (v is DocumentReference) return v.path;
    return v?.toString();
  }

  Timer? _persistItemsTimer;

  Future<void> _persistItemsCache(List<Map<String, dynamic>> items) async {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) return;
    items = items.map((e) => Map<String, dynamic>.from(e)).toList();
    _itemsMemoryByUid[uid] = items;
    // Listener bursts would re-encode the whole list each time.
    _persistItemsTimer?.cancel();
    _persistItemsTimer = Timer(
      const Duration(seconds: 2),
      () => unawaited(_writeItemsCache(uid, items)),
    );
  }

  Future<void> _writeItemsCache(String uid, List<Map<String, dynamic>> copy) async {
    try {
      // Keep prefs payload small G?? drop huge base64 blobs from disk cache.
      final slim = copy.map((e) {
        final m = Map<String, dynamic>.from(e);
        final img = (m['image'] ?? '').toString();
        if (img.length > 4000) m.remove('image');
        final gal = m['gallery'];
        if (gal is List && gal.isNotEmpty) {
          m['gallery'] = gal.take(2).where((x) {
            return x.toString().length < 4000;
          }).toList();
        }
        return m;
      }).toList();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        '$_prefsItemsCachePrefix$uid',
        jsonEncode(slim, toEncodable: _jsonSafe),
      );
    } catch (e) {
      if (kDebugMode) debugPrint('[My Items] cache write failed: $e');
    }
  }

  void _applyItemsToUi(List<Map<String, dynamic>> list, {bool persist = true}) {
    final total = list.length;
    final active = list.where(_countsAsActiveListing).length;
    if (!mounted) {
      if (persist) unawaited(_persistItemsCache(list));
      return;
    }
    setState(() {
      _items = list;
      _totalItems = total;
      _activeItems = active;
      _loadingItems = false;
    });
    if (persist) unawaited(_persistItemsCache(list));
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _itemsByUidSub?.cancel();
    _itemsByNestSub?.cancel();
    _mergeItemsTimer?.cancel();
    _persistItemsTimer?.cancel();
    _marketplaceTabs.dispose();
    _priceFocus.removeListener(_onPriceFieldFocused);
    _priceFocus.dispose();
    _name.dispose();
    _price.dispose();
    _location.dispose();
    _desc.dispose();
    _stock.dispose();
    _recentSalesSearchController.dispose();
    _recentSalesSearchFocus.dispose();
    super.dispose();
  }

  void _startPeriodicUpdates() {
    _ticker?.cancel();
    var tick = 0;
    // Lighter polling on low-RAM devices: wallet often, heavy order dump rarely.
    _ticker = Timer.periodic(const Duration(seconds: 60), (_) {
      if (!mounted) return;
      if (_sheetOpen) return;
      tick++;
      _hydrateFromFirebaseAuth();
      unawaited(_loadWalletBalance());
      if (tick % 3 == 0) unawaited(_loadOrderStats());
      if (tick % 4 == 0) unawaited(_fetchCurrentUserMe());
    });
  }

  // ----------------- Business name FIX (Auth G?? Firestore G?? API G?? Prefs) -----------------
  void _hydrateFromFirebaseAuth() {
    final u = _auth.currentUser;
    if (u == null) return;

    _uid = u.uid;

    final email = (u.email ?? '').trim();
    final phone = _sanitizePhone(u.phoneNumber ?? '');
    final photo = (u.photoURL ?? '').trim();

    if (mounted) {
      setState(() {
        if (email.isNotEmpty) _merchantEmail = email;
        if (phone.isNotEmpty) _merchantPhone = phone;
        if (photo.isNotEmpty) {
          _merchantProfileUrl = photo;
        } else {
          // Avoid keeping a previous account's avatar while prefs/Firestore load.
          _localPhotoPath = null;
        }
      });
    }
    if (photo.isNotEmpty) {
      unawaited(_warmProfilePhotoCache(photo));
    } else {
      // Drop disk avatar if Auth has no photo for this user yet.
      unawaited(ProfilePhotoCache.peekLocalPath().then((path) async {
        if (path != null) await ProfilePhotoCache.clear();
      }));
    }
  }

  /// Pull phone and profile picture from Firestore users/{uid} when Auth/prefs are empty.
  Future<void> _pullPhoneAndProfileFromFirestore() async {
    final uid = _auth.currentUser?.uid ?? _uid;
    if (uid.isEmpty) return;
    try {
      final doc = await _sharedDoc('users', uid);
      final data = doc.data();
      if (data == null || !mounted) return;
      final phoneVal = _sanitizePhone(
          (data['phone'] ?? '').toString().trim());
      final picVal = (data['profilePicture'] ?? data['profilepicture'] ?? '')
          .toString()
          .trim();
      final descVal = (data['businessDescription'] ?? data['description'] ?? '')
          .toString()
          .trim();
      final hoursVal = (data['openingHours'] ?? '').toString().trim();
      final daysVal = data['openingDays'];
      final locVal = (data['businessLocation'] ??
              data['address'] ??
              data['listingLocation'] ??
              '')
          .toString()
          .trim();
      final latRaw = data['latitude'] ?? data['lat'];
      final lngRaw = data['longitude'] ?? data['lng'];
      final latVal = latRaw is num
          ? latRaw.toDouble()
          : double.tryParse('$latRaw');
      final lngVal = lngRaw is num
          ? lngRaw.toDouble()
          : double.tryParse('$lngRaw');
      if (phoneVal.isEmpty &&
          picVal.isEmpty &&
          descVal.isEmpty &&
          hoursVal.isEmpty &&
          daysVal == null &&
          locVal.isEmpty) {
        return;
      }
      final prefs = await SharedPreferences.getInstance();
      if (phoneVal.isNotEmpty) {
        await prefs.setString('phone', phoneVal);
        await prefs.setString('merchant_profile_phone', phoneVal);
      }
      if (picVal.isNotEmpty) await prefs.setString('profilepicture', picVal);
      if (descVal.isNotEmpty) {
        await prefs.setString(_kBusinessDescPrefKey, descVal);
      }
      if (hoursVal.isNotEmpty) {
        await prefs.setString(_kShopHoursPrefKey, hoursVal);
      }
      if (daysVal != null) {
        final tmp = <int>{};
        if (daysVal is List) {
          for (final e in daysVal) {
            final n = e is int ? e : int.tryParse('$e');
            if (n != null && n >= 1 && n <= 7) tmp.add(n);
          }
        }
        if (tmp.isNotEmpty) {
          await prefs.setString(
              _kShopDaysPrefKey, (tmp.toList()..sort()).join(','));
        }
      }
      if (locVal.isNotEmpty) {
        await prefs.setString(_kBusinessLocationPrefKey, locVal);
        if (latVal != null) await prefs.setDouble(_kBusinessLatPrefKey, latVal);
        if (lngVal != null) await prefs.setDouble(_kBusinessLngPrefKey, lngVal);
      }
      if (!mounted) return;
      setState(() {
        if (phoneVal.isNotEmpty && _merchantPhone == 'No Phone') {
          _merchantPhone = phoneVal;
        }
        if (picVal.isNotEmpty) {
          _merchantProfileUrl = picVal;
        }
        if (descVal.isNotEmpty) {
          _businessDescription = descVal;
        }
        if (hoursVal.isNotEmpty) {
          _applyOpeningHoursString(hoursVal);
        }
        if (daysVal != null) {
          _applyOpeningDays(daysVal);
        }
        if (locVal.isNotEmpty) {
          _businessLocation = locVal;
          if (latVal != null) _businessLat = latVal;
          if (lngVal != null) _businessLng = lngVal;
        }
      });
      if (picVal.isNotEmpty) {
        unawaited(_warmProfilePhotoCache(picVal));
      }
    } catch (_) {}
  }

  Future<void> _syncBackendUserIdToFirestore() async {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) return;
    final nestRaw = await _getNestUserId();
    final backendId = int.tryParse(nestRaw ?? '');
    if (backendId == null || backendId <= 0) return;
    // Rewrites up to 100 listings; once a day is enough.
    final prefs = await SharedPreferences.getInstance();
    final syncKey = 'merchant_backend_id_synced_$uid';
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (prefs.getString(syncKey) == '$backendId@$today') return;
    try {
      await _firestore.collection('marketplace_merchants').doc(uid).set(
        {
          'backendUserId': backendId,
          'userId': backendId,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      await _firestore.collection('users').doc(uid).set(
        {
          'userId': backendId,
          'backendUserId': backendId,
          'firebaseUid': uid,
          'uid': uid,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      await _backfillMerchantBackendIdOnItems(uid, backendId, nestRaw!);
      await prefs.setString(syncKey, '$backendId@$today');
    } catch (e) {
      debugPrint('sync backendUserId: $e');
    }
  }

  /// Tags existing Firestore listings so buyers can open chat (merchantBackendId).
  Future<void> _backfillMerchantBackendIdOnItems(
    String firebaseUid,
    int backendId,
    String nestUserId,
  ) async {
    try {
      final snap = await _firestore
          .collection('marketplace_items')
          .where('merchantId', isEqualTo: firebaseUid)
          .limit(100)
          .get();
      if (snap.docs.isEmpty) return;

      final batch = _firestore.batch();
      var updates = 0;
      for (final doc in snap.docs) {
        final data = doc.data();
        final existing = data['merchantBackendId'];
        final seller = data['sellerUserId']?.toString().trim() ?? '';
        final existingId = existing is num
            ? existing.toInt()
            : int.tryParse('${existing ?? ''}');
        final needsBackendId = existingId == null || existingId <= 0;
        final sellerIsUid = seller.isEmpty ||
            RegExp(r'^[A-Za-z0-9_-]{20,}$').hasMatch(seller);
        if (!needsBackendId && !sellerIsUid) continue;

        batch.set(
          doc.reference,
          {
            if (needsBackendId) 'merchantBackendId': backendId,
            if (sellerIsUid) 'sellerUserId': nestUserId,
            'updatedAt': FieldValue.serverTimestamp(),
          },
          SetOptions(merge: true),
        );
        updates++;
        if (updates >= 450) break;
      }
      if (updates > 0) await batch.commit();
    } catch (e) {
      debugPrint('backfill merchantBackendId: $e');
    }
  }

  Future<void> _ensureBusinessName() async {
    final u = _auth.currentUser;
    if (u == null) return;

    final authDisplay = (u.displayName ?? '').trim();
    String resolved = '';

    String? fromMap(Map<String, dynamic>? m, {bool includeListingName = false}) {
      if (m == null) return null;
      for (final k in [
        'businessName',
        'business_name',
        'merchantName',
        'merchant_name',
        'companyName',
        'company_name',
      ]) {
        final v = m[k]?.toString().trim();
        if (v != null && v.isNotEmpty) return v;
      }
      if (includeListingName) {
        final v = m['name']?.toString().trim();
        if (v != null && v.isNotEmpty) return v;
      }
      return null;
    }

    try {
      final cached = await _firestore
          .collection('marketplace_merchants')
          .doc(u.uid)
          .get(const GetOptions(source: Source.cache));
      final fromCache = fromMap(cached.data(), includeListingName: true);
      if (fromCache != null &&
          fromCache.isNotEmpty &&
          mounted &&
          _businessName.trim().isEmpty) {
        setState(() => _businessName = fromCache);
      }
    } catch (_) {}

    // Always hydrate shop profile fields from marketplace_merchants.
    try {
      final doc = await _sharedDoc('marketplace_merchants', u.uid);
      final data = doc.data();
      if (data != null) {
        final fromDoc = fromMap(data, includeListingName: true);
        if (fromDoc != null && fromDoc.isNotEmpty) resolved = fromDoc;
        final desc = (data['businessDescription'] ?? data['description'] ?? '')
            .toString()
            .trim();
        final hours = (data['openingHours'] ?? '').toString().trim();
        final days = data['openingDays'];
        final loc = (data['businessLocation'] ??
                data['address'] ??
                data['listingLocation'] ??
                data['location'] ??
                '')
            .toString()
            .trim();
        final latRaw = data['latitude'] ?? data['lat'];
        final lngRaw = data['longitude'] ?? data['lng'];
        final lat = latRaw is num
            ? latRaw.toDouble()
            : double.tryParse('$latRaw');
        final lng = lngRaw is num
            ? lngRaw.toDouble()
            : double.tryParse('$lngRaw');
        if (desc.isNotEmpty && mounted) {
          setState(() => _businessDescription = desc);
          unawaited(SharedPreferences.getInstance().then((p) {
            p.setString(_kBusinessDescPrefKey, desc);
          }));
        }
        if ((hours.isNotEmpty || days != null) && mounted) {
          setState(() {
            if (hours.isNotEmpty) _applyOpeningHoursString(hours);
            if (days != null) _applyOpeningDays(days);
          });
          unawaited(SharedPreferences.getInstance().then((p) {
            if (hours.isNotEmpty) p.setString(_kShopHoursPrefKey, hours);
            if (days is List) {
              final tmp = <int>[];
              for (final e in days) {
                final n = e is int ? e : int.tryParse('$e');
                if (n != null && n >= 1 && n <= 7) tmp.add(n);
              }
              if (tmp.isNotEmpty) {
                tmp.sort();
                p.setString(_kShopDaysPrefKey, tmp.join(','));
              }
            }
          }));
        }
        if (loc.isNotEmpty && mounted) {
          setState(() {
            _businessLocation = loc;
            if (lat != null) _businessLat = lat;
            if (lng != null) _businessLng = lng;
          });
          unawaited(SharedPreferences.getInstance().then((p) async {
            await p.setString(_kBusinessLocationPrefKey, loc);
            if (lat != null) await p.setDouble(_kBusinessLatPrefKey, lat);
            if (lng != null) await p.setDouble(_kBusinessLngPrefKey, lng);
          }));
        }
      }
    } catch (_) {}

    // 2) Firestore users — business fields only (not personal name).
    if (resolved.isEmpty) {
      try {
        final doc = await _sharedDoc('users', u.uid);
        final fromUser = fromMap(doc.data());
        if (fromUser != null && fromUser.isNotEmpty) resolved = fromUser;
      } catch (_) {}
    }

    // 3) Prefs
    if (resolved.isEmpty) {
      final prefs = await SharedPreferences.getInstance();
      resolved = (prefs.getString('business_name') ?? '').trim();
    }

    // 4) API /users/me
    if (resolved.isEmpty) {
      final user = await _usersMe();
      if (user != null) {
        final business = (user['businessName'] ?? user['merchantName'] ?? '')
            .toString()
            .trim();
        if (business.isNotEmpty) resolved = business;
      }
    }

    if (resolved.isEmpty && authDisplay.isNotEmpty) {
      resolved = authDisplay;
    }

    if (resolved.isEmpty) resolved = 'Marketplace Merchant';
    final already = _businessName.trim();
    if (resolved == 'Marketplace Merchant' &&
        already.isNotEmpty &&
        already != 'Marketplace Merchant') {
      resolved = already;
    }
    if (resolved != 'Marketplace Merchant') {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('business_name', resolved);
      await prefs.setString('marketplace_business_name_${u.uid}', resolved);
    }

    // backfill FirebaseAuth displayName
    try {
      if ((u.displayName ?? '').trim().isEmpty &&
          resolved != 'Marketplace Merchant') {
        await u.updateDisplayName(resolved);
      }
    } catch (_) {}

    if (!mounted) return;
    setState(() => _businessName = resolved);
  }

  String _displayBusinessName() {
    if (_businessName.trim().isNotEmpty) return _businessName.trim();
    return 'Marketplace Merchant';
  }

  Future<Map<String, dynamic>?>? _usersMeRead;
  DateTime _usersMeAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// `/users/me` user object, shared by every loader for 30s.
  Future<Map<String, dynamic>?> _usersMe() {
    final fresh = DateTime.now().difference(_usersMeAt) < const Duration(seconds: 30);
    if (_usersMeRead != null && fresh) return _usersMeRead!;
    _usersMeAt = DateTime.now();
    return _usersMeRead = () async {
      try {
        final bearer = await _getBearerTokenForApi();
        if (bearer == null || bearer.isEmpty) return null;
        final base = await ApiConfig.readBase();
        final resp = await http.get(
          Uri.parse('$base/users/me'),
          headers: {
            'Authorization': 'Bearer $bearer',
            'Accept': 'application/json'
          },
        ).timeout(const Duration(seconds: 20));
        if (resp.statusCode != 200) {
          _usersMeRead = null;
          return null;
        }
        final decoded = jsonDecode(resp.body);
        final Map<String, dynamic> payload =
            (decoded is Map && decoded['data'] is Map)
                ? Map<String, dynamic>.from(decoded['data'])
                : (decoded is Map ? Map<String, dynamic>.from(decoded) : {});
        return (payload['user'] is Map)
            ? Map<String, dynamic>.from(payload['user'] as Map)
            : payload;
      } catch (_) {
        _usersMeRead = null;
        return null;
      }
    }();
  }

  // ----------------- API auth: prefs token OR Firebase idToken -----------------
  /// [forceRefresh] true = get a new Firebase ID token (use before sensitive/upload calls to avoid auth/id-token-expired).
  Future<String?> _getBearerTokenForApi({bool forceRefresh = false}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null && forceRefresh) {
      try {
        final idToken = await user.getIdToken(true);
        final t = idToken?.trim();
        if (t != null && t.isNotEmpty) return t;
      } catch (_) {}
    }

    final prefs = await SharedPreferences.getInstance();
    final fromPrefs = prefs.getString('jwt_token') ??
        prefs.getString('token') ??
        prefs.getString('authToken') ??
        prefs.getString('jwt');

    if (fromPrefs != null && fromPrefs.trim().isNotEmpty) {
      return fromPrefs.trim();
    }

    if (user == null) return null;

    try {
      final idToken = await user.getIdToken(forceRefresh);
      final t = idToken?.trim();
      if (t == null || t.isEmpty) return null;
      return t;
    } catch (_) {
      return null;
    }
  }

  Future<void> _loadMerchantProfileFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    final currentUid = (_auth.currentUser?.uid ?? _uid).trim();
    final cachedName = (prefs.getString('marketplace_business_name_$currentUid') ??
            prefs.getString('business_name') ??
            '')
        .trim();
    if (cachedName.isNotEmpty && cachedName != 'Marketplace Merchant') {
      setState(() => _businessName = cachedName);
    }
    final phone = _sanitizePhone(
      prefs.getString('merchant_profile_phone') ?? prefs.getString('phone') ?? '',
    );
    final pic =
        (prefs.getString('profilepicture') ?? '').trim();
    final desc = (prefs.getString(_kBusinessDescPrefKey) ?? '').trim();
    final hours = (prefs.getString(_kShopHoursPrefKey) ?? '').trim();
    final daysRaw = (prefs.getString(_kShopDaysPrefKey) ?? '').trim();
    final location = (prefs.getString(_kBusinessLocationPrefKey) ?? '').trim();
    final lat = prefs.getDouble(_kBusinessLatPrefKey);
    final lng = prefs.getDouble(_kBusinessLngPrefKey);

    // Only use on-disk avatar when it matches this account + URL.
    final localPath = pic.isEmpty
        ? null
        : await ProfilePhotoCache.peekLocalPath(forRemoteUrl: pic);

    if (!mounted) return;

    // Prefer live Firebase Auth photo over a stale prefs URL from another session.
    final authPhoto = (_auth.currentUser?.photoURL ?? '').trim();
    final nextPic = pic.isNotEmpty
        ? pic
        : (authPhoto.isNotEmpty ? authPhoto : _merchantProfileUrl);

    setState(() {
      if (currentUid.isNotEmpty) _uid = currentUid;
      _merchantEmail = prefs.getString('email') ?? _merchantEmail;
      if (phone.isNotEmpty) _merchantPhone = phone;
      _merchantProfileUrl = nextPic;
      _localPhotoPath = localPath;
      if (desc.isNotEmpty) _businessDescription = desc;
      if (hours.isNotEmpty) _applyOpeningHoursString(hours);
      if (daysRaw.isNotEmpty) _applyOpeningDays(daysRaw);
      if (location.isNotEmpty) _businessLocation = location;
      if (lat != null) _businessLat = lat;
      if (lng != null) _businessLng = lng;
    });
    // Warm/refresh disk cache in background so next open is instant.
    if (_merchantProfileUrl.trim().isNotEmpty) {
      unawaited(_warmProfilePhotoCache(_merchantProfileUrl));
    }
  }

  Future<void> _warmProfilePhotoCache([String? url]) async {
    final remote = (url ?? _merchantProfileUrl).trim();
    if (remote.isEmpty) return;
    final file = await ProfilePhotoCache.ensureCached(remote);
    if (!mounted || file == null) return;
    if (_localPhotoPath == file.path) return;
    setState(() => _localPhotoPath = file.path);
  }

  Future<void> _writeMerchantProfile(Map<String, dynamic> payload) async {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) throw Exception('Not signed in');
    final withTs = {
      ...payload,
      'updatedAt': FieldValue.serverTimestamp(),
    };
    await Future.wait([
      _firestore
          .collection('marketplace_merchants')
          .doc(uid)
          .set(withTs, SetOptions(merge: true)),
      _firestore
          .collection('users')
          .doc(uid)
          .set(withTs, SetOptions(merge: true)),
    ]);
  }

  Future<T?> _openProfileSheet<T>(WidgetBuilder builder) async {
    _sheetOpen = true;
    try {
      return await showModalBottomSheet<T>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: builder,
      );
    } finally {
      _sheetOpen = false;
    }
  }

  Future<void> _editBusinessDescription() async {
    final saved = await _openProfileSheet<String>(
      (ctx) => _BusinessDescriptionSheet(
        initialText: _businessDescription,
        maxLength: _kBusinessDescMaxLen,
        brandColor: _brandOrange,
      ),
    );
    if (saved == null || !mounted) return;
    await _saveBusinessDescription(saved);
  }

  Future<void> _saveBusinessDescription(String raw) async {
    final desc = DescriptionContactMask.mask(raw.trim());
    if (desc.length > _kBusinessDescMaxLen) {
      _toastErr('Keep it under $_kBusinessDescMaxLen characters.');
      return;
    }
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) {
      _toastErr('Please sign in again.');
      return;
    }

    try {
      setState(() => _profileBusy = true);
      await _writeMerchantProfile({
        'businessDescription': desc,
        'description': desc,
      });
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kBusinessDescPrefKey, desc);
      if (!mounted) return;
      setState(() => _businessDescription = desc);
      _toastOk(desc.isEmpty ? 'Description cleared' : 'Description saved');
    } catch (e) {
      debugPrint('Save business description: $e');
      if (!mounted) return;
      _toastErr('Could not save description. Try again.');
    } finally {
      if (mounted) setState(() => _profileBusy = false);
    }
  }

  void _applyOpeningHoursString(String raw) {
    final pair = MarketplaceShopHours.parseRange(raw);
    if (pair == null) {
      _openTime = null;
      _closeTime = null;
      return;
    }
    _openTime = pair.open;
    _closeTime = pair.close;
  }

  void _applyOpeningDays(dynamic raw) {
    _openDays = MarketplaceShopHours.parseDays(raw).toSet();
  }

  static const _kDayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  String _formatOpenDaysLabel(Set<int> days) {
    if (days.isEmpty || days.length == 7) return 'Every day';
    final sorted = days.toList()..sort();
    // Contiguous ranges — Mon–Fri style
    final ranges = <String>[];
    int start = sorted.first;
    int prev = sorted.first;
    for (var i = 1; i < sorted.length; i++) {
      final d = sorted[i];
      if (d == prev + 1) {
        prev = d;
        continue;
      }
      ranges.add(start == prev
          ? _kDayLabels[start - 1]
          : '${_kDayLabels[start - 1]}–${_kDayLabels[prev - 1]}');
      start = prev = d;
    }
    ranges.add(start == prev
        ? _kDayLabels[start - 1]
        : '${_kDayLabels[start - 1]}–${_kDayLabels[prev - 1]}');
    return ranges.join(', ');
  }

  String get _shopHoursSummary {
    if (_openTime == null || _closeTime == null) return 'Set shop hours';
    final times =
        MarketplaceShopHours.formatRangeDisplay(_openTime!, _closeTime!);
    return '${_formatOpenDaysLabel(_openDays)} · $times';
  }

  bool get _isShopOpenNow {
    if (_openTime == null || _closeTime == null) return false;
    return MarketplaceShopHours.isOpenNow(
      MarketplaceShopHours.formatRange(_openTime!, _closeTime!),
      _openDays.toList(),
    );
  }

  Future<void> _editShopHours() async {
    final result = await _openProfileSheet<
        ({TimeOfDay open, TimeOfDay close, Set<int> days})>(
      (ctx) => _ShopHoursSheet(
        initialOpen: _openTime ?? const TimeOfDay(hour: 8, minute: 0),
        initialClose: _closeTime ?? const TimeOfDay(hour: 17, minute: 0),
        initialDays: _openDays.isEmpty
            ? {1, 2, 3, 4, 5, 6, 7}
            : Set<int>.from(_openDays),
        brandColor: _brandOrange,
      ),
    );
    if (result == null || !mounted) return;
    await _saveShopHours(result.open, result.close, result.days);
  }

  Future<void> _saveShopHours(
    TimeOfDay open,
    TimeOfDay close,
    Set<int> days,
  ) async {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) {
      _toastErr('Please sign in again.');
      return;
    }
    final hours = MarketplaceShopHours.formatRange(open, close);
    final dayList = (days.isEmpty || days.length == 7)
        ? <int>[1, 2, 3, 4, 5, 6, 7]
        : (days.toList()..sort());
    try {
      setState(() => _profileBusy = true);
      await _writeMerchantProfile({
        'openingHours': hours,
        'openingDays': dayList,
      });
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kShopHoursPrefKey, hours);
      await prefs.setString(_kShopDaysPrefKey, dayList.join(','));
      MerchantSellerLoader.cacheOpeningHours(uid, hours);
      MerchantSellerLoader.cacheOpeningDays(uid, dayList);
      if (!mounted) return;
      setState(() {
        _openTime = open;
        _closeTime = close;
        _openDays = dayList.toSet();
      });
      _toastOk('Shop hours saved');
    } catch (e) {
      debugPrint('Save shop hours: $e');
      if (!mounted) return;
      _toastErr('Could not save hours. Try again.');
    } finally {
      if (mounted) setState(() => _profileBusy = false);
    }
  }

  Future<void> _editBusinessName() async {
    final saved = await _openProfileSheet<String>(
      (ctx) => _MarketplaceBusinessNameSheet(
        initialText: _displayBusinessName(),
        brandColor: _brandOrange,
      ),
    );
    if (saved == null || !mounted) return;
    await _saveBusinessName(saved);
  }

  Future<void> _saveBusinessName(String raw) async {
    final name = raw.trim();
    if (name.length < 2) {
      _toastErr('Enter a shop name customers can recognize.');
      return;
    }
    if (name.length > 80) {
      _toastErr('Keep the name under 80 characters.');
      return;
    }
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) {
      _toastErr('Please sign in again.');
      return;
    }
    try {
      setState(() => _profileBusy = true);
      await _writeMerchantProfile({
        'businessName': name,
        'name': name,
        'merchantName': name,
      });
      try {
        final items = await _firestore
            .collection('marketplace_items')
            .where('merchantId', isEqualTo: uid)
            .limit(200)
            .get();
        final batch = _firestore.batch();
        for (final d in items.docs) {
          batch.set(
            d.reference,
            {
              'businessName': name,
              'merchantName': name,
              'updatedAt': FieldValue.serverTimestamp(),
            },
            SetOptions(merge: true),
          );
        }
        if (items.docs.isNotEmpty) await batch.commit();
      } catch (e) {
        debugPrint('Sync listing business name: $e');
      }
      try {
        await _auth.currentUser?.updateDisplayName(name);
      } catch (_) {}
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('business_name', name);
      if (!mounted) return;
      setState(() => _businessName = name);
      _toastOk('Shop name saved');
    } catch (e) {
      debugPrint('Save business name: $e');
      if (mounted) _toastErr('Could not save name. Try again.');
    } finally {
      if (mounted) setState(() => _profileBusy = false);
    }
  }

  Future<void> _editPhone() async {
    final initial = _displayMerchantPhone == 'No Phone'
        ? ''
        : _displayMerchantPhone;
    final saved = await _openProfileSheet<String>(
      (ctx) => _MarketplacePhoneSheet(
        initialPhone: initial,
        brandColor: _brandOrange,
      ),
    );
    if (saved == null || !mounted) return;
    await _savePhone(saved);
  }

  Future<void> _savePhone(String raw) async {
    final phone = _sanitizePhone(raw.trim());
    if (phone.length < 7) {
      _toastErr('Enter a valid phone number.');
      return;
    }
    try {
      setState(() => _profileBusy = true);
      await _writeMerchantProfile({
        'phone': phone,
        'phoneNumber': phone,
        'contact': phone,
      });
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('phone', phone);
      await prefs.setString('merchant_profile_phone', phone);
      if (!mounted) return;
      setState(() => _merchantPhone = phone);
      _toastOk('Phone number saved');
    } catch (e) {
      debugPrint('Save phone: $e');
      if (mounted) _toastErr('Could not save phone. Try again.');
    } finally {
      if (mounted) setState(() => _profileBusy = false);
    }
  }

  Future<void> _editBusinessLocation() async {
    _sheetOpen = true;
    Place? place;
    try {
      place = await Navigator.of(context).push<Place>(
        MaterialPageRoute(
          builder: (_) => FoodBusinessLocationPickerPage(
          initialAddress: _businessLocation,
          initialLatitude: _businessLat,
          initialLongitude: _businessLng,
          title: 'Shop location',
          hint:
              'Type your address, search for a place, or pin your storefront.',
          emptyAddressMessage: 'Type your shop address first.',
          mapPinHintSubtitle:
              'Drop a pin exactly where your storefront is.',
        ),
        ),
      );
    } finally {
      _sheetOpen = false;
    }
    if (place == null || !mounted) return;
    var label = place.address.trim().isNotEmpty
        ? place.address.trim()
        : place.name.trim();
    if (label.isNotEmpty && GooglePlacesService.isPlusCodeLabel(label)) {
      try {
        final decoded = await GooglePlacesService().lookupStreetName(
          label,
          biasLat: place.latitude,
          biasLng: place.longitude,
        );
        final rev = decoded ??
            await GooglePlacesService().reverseGeocode(
              latitude: place.latitude,
              longitude: place.longitude,
            );
        if (rev != null) {
          final name = rev.name.trim();
          final addr = rev.address.trim();
          if (name.isNotEmpty && !GooglePlacesService.isPlusCodeLabel(name)) {
            label = addr.isNotEmpty && !GooglePlacesService.isPlusCodeLabel(addr)
                ? addr
                : name;
          } else if (addr.isNotEmpty &&
              !GooglePlacesService.isPlusCodeLabel(addr)) {
            label = addr;
          }
        }
      } catch (e) {
        debugPrint('Decode marketplace plus-code location: $e');
      }
    }
    if (label.isEmpty) {
      _toastErr('Could not read that location. Try again.');
      return;
    }
    try {
      setState(() => _profileBusy = true);
      await _writeMerchantProfile({
        'businessLocation': label,
        'address': label,
        'location': label,
        'listingLocation': label,
        'latitude': place.latitude,
        'longitude': place.longitude,
        'lat': place.latitude,
        'lng': place.longitude,
      });
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kBusinessLocationPrefKey, label);
      await prefs.setDouble(_kBusinessLatPrefKey, place.latitude);
      await prefs.setDouble(_kBusinessLngPrefKey, place.longitude);
      if (!mounted) return;
      setState(() {
        _businessLocation = label;
        _businessLat = place!.latitude;
        _businessLng = place.longitude;
      });
      _toastOk('Shop location saved');
    } catch (e) {
      debugPrint('Save business location: $e');
      if (mounted) _toastErr('Could not save location. Try again.');
    } finally {
      if (mounted) setState(() => _profileBusy = false);
    }
  }

  // G?? /users/me for email/phone/pic/rating
  Future<void> _fetchCurrentUserMe() async {
    if (!mounted) return;

    setState(() {
      _loadingMe = true;
    });

    try {
      final user = await _usersMe();
      if (!mounted) return;

      if (user != null) {
        final emailVal =
            (user['email'] ?? user['userEmail'] ?? '').toString().trim();
        final phoneVal = _sanitizePhone(
            (user['phone'] ?? '').toString().trim());
        final picVal = (user['profilepicture'] ?? user['profilePicture'] ?? '')
            .toString()
            .trim();

        final apiRating = user['rating'];
        if (apiRating is num) _rating = apiRating.toDouble();

        // Pull verification/status from API (e.g. pending, approved, under_review)
        final apiStatus = (user['status'] ?? user['verificationStatus'] ?? '')
            .toString()
            .trim();
        if (apiStatus.isNotEmpty) _status = apiStatus;

        final prefs = await SharedPreferences.getInstance();
        if (emailVal.isNotEmpty) await prefs.setString('email', emailVal);
        if (phoneVal.isNotEmpty) {
          await prefs.setString('phone', phoneVal);
          await prefs.setString('merchant_profile_phone', phoneVal);
        }
        if (picVal.isNotEmpty) await prefs.setString('profilepicture', picVal);

        if (!mounted) return;
        final authPhoto = (_auth.currentUser?.photoURL ?? '').trim();
        final nextPic = authPhoto.isNotEmpty
            ? authPhoto
            : (picVal.isNotEmpty ? picVal : _merchantProfileUrl);
        setState(() {
          if (emailVal.isNotEmpty) _merchantEmail = emailVal;
          if (phoneVal.isNotEmpty) _merchantPhone = phoneVal;
          // Prefer Firebase Auth photo; else use API profile picture
          if (nextPic.trim().isNotEmpty) _merchantProfileUrl = nextPic;
        });
        if (nextPic.trim().isNotEmpty) {
          unawaited(_warmProfilePhotoCache(nextPic));
        }
      }
    } catch (e) {
      if (kDebugMode) debugPrint('Error fetching /users/me');
    } finally {
      if (mounted) setState(() => _loadingMe = false);
    }
  }

  // ----------------- Dashboard API + Wallet -----------------
  final Map<String, ({DateTime at, Future<DocumentSnapshot<Map<String, dynamic>>> read})>
      _docReads = {};

  /// Profile, KYC and business-name loaders all read the same docs at startup;
  /// share one read per doc for a few seconds.
  Future<DocumentSnapshot<Map<String, dynamic>>> _sharedDoc(String collection, String id) {
    final key = '$collection/$id';
    final hit = _docReads[key];
    if (hit != null && DateTime.now().difference(hit.at) < const Duration(seconds: 20)) {
      return hit.read;
    }
    final read = _firestore.collection(collection).doc(id).get();
    _docReads[key] = (at: DateTime.now(), read: read);
    unawaited(read.then((_) {}, onError: (_) => _docReads.remove(key)));
    return read;
  }

  Future<void> _loadMerchantData() async {
    if (!mounted) return;

    final prefs = await SharedPreferences.getInstance();
    _uid = _auth.currentUser?.uid ?? prefs.getString('uid') ?? _uid;

    if (_uid.isNotEmpty) {
      try {
        // Earnings / sold / recent sales come from real merchant orders in
        // _loadOrderStats(); only the merchant profile doc is needed here.
        final doc = await _sharedDoc('marketplace_merchants', _uid);
        final merchant = doc.data();
        if (merchant != null) {
          if (!mounted) return;
          setState(() {
            final mr = merchant['rating'];
            if (mr is num) _rating = mr.toDouble();

            final ms = merchant['status'];
            if (ms != null && ms.toString().trim().isNotEmpty) {
              _status = ms.toString().trim();
            }

            final mp = _sanitizePhone(
                (merchant['phone'] ?? '').toString().trim());
            if (mp.isNotEmpty) {
              _merchantPhone = mp;
              unawaited(prefs.setString('merchant_profile_phone', mp));
            }
          });
        }
      } catch (e) {
        debugPrint('Error loading dashboard: $e');
      }
    }

    if (mounted) {
      setState(() {
        _isLoading = false;
        _initialLoadComplete = true;
      });
    }
  }

  /// Load sold items count, total earnings, and recent sales from this
  /// merchant's incoming orders (and escrow as a fast/accurate fallback).
  Future<void>? _orderStatsInFlight;

  /// Fetching every merchant order is the heaviest call here; never run two at once.
  Future<void> _loadOrderStats() => _orderStatsInFlight ??=
      _loadOrderStatsNow().whenComplete(() => _orderStatsInFlight = null);

  Future<void> _loadOrderStatsNow() async {
    if (!mounted) return;
    final myFirebaseUid = (_auth.currentUser?.uid ?? _uid).trim();

    // Escrow is local Firestore — paint a real figure immediately.
    unawaited(_applyEscrowEarnings(myFirebaseUid));

    try {
      final nestId = (await _getNestUserId(allowNetwork: false) ?? '').trim();
      final orders = await _orderService.getMerchantOrders();

      final sold = orders.where((o) {
        if (o.status == OrderStatus.cancelled) return false;
        final sellerUid = (o.merchantUid ?? '').trim();
        // `/orders/merchant/me` is already this merchant. Only drop rows that
        // clearly belong to someone else (e.g. this merchant's own purchases).
        if (sellerUid.isNotEmpty &&
            myFirebaseUid.isNotEmpty &&
            sellerUid != myFirebaseUid &&
            (nestId.isEmpty || sellerUid != nestId)) {
          final buyer = (o.customerUid ?? '').trim();
          if (buyer == myFirebaseUid) return false;
        }
        if (o.status == OrderStatus.delivered) return true;
        if (o.paymentStatus == PaymentStatus.paid) return true;
        return false;
      }).toList();

      sold.sort((a, b) {
        final da = a.orderDate ?? DateTime(0);
        final db = b.orderDate ?? DateTime(0);
        return db.compareTo(da);
      });

      final refunds = await _completedRefundAmounts(myFirebaseUid);
      if (!mounted) return;
      final counted = sold.where((o) => !_orderFullyRefunded(o, refunds)).toList();

      setState(() {
        _soldItems = counted.length;
        _recentSalesOrders = counted.take(25).toList(growable: false);
        _publishFreshEarnings();
      });
      unawaited(_persistEarningsCache(
        sold: _soldItems,
        earnings: _totalEarnings,
      ));
      unawaited(_stampSoldListings(counted));
    } catch (e) {
      debugPrint('Error loading order stats: $e');
    }
  }

  /// Paid orders that used up the listing stock should leave Live and show Sold.
  Future<void> _stampSoldListings(List<OrderItem> soldOrders) async {
    if (!mounted || soldOrders.isEmpty || _items.isEmpty) return;

    final qtyBySql = <int, int>{};
    final qtyByName = <String, int>{};
    for (final o in soldOrders) {
      final id = o.itemSqlId;
      if (id != null && id > 0) {
        qtyBySql[id] = (qtyBySql[id] ?? 0) + o.quantity;
      }
      final name = o.itemName.trim().toLowerCase();
      if (name.isNotEmpty) {
        qtyByName[name] = (qtyByName[name] ?? 0) + o.quantity;
      }
    }

    final nameCounts = <String, int>{};
    for (final it in _items) {
      final name = (it['name'] ?? '').toString().trim().toLowerCase();
      if (name.isEmpty) continue;
      nameCounts[name] = (nameCounts[name] ?? 0) + 1;
    }

    final updates = <String, Map<String, dynamic>>{};
    for (final raw in _items) {
      if (_itemIsSold(raw)) continue;
      final docId = (raw['id'] ?? '').toString().trim();
      if (docId.isEmpty) continue;

      int? sql;
      final rawSql = raw['sqlItemId'] ?? raw['backendId'] ?? raw['itemId'];
      if (rawSql is num) {
        sql = rawSql.toInt();
      } else {
        sql = int.tryParse('${rawSql ?? ''}');
      }
      final name = (raw['name'] ?? '').toString().trim().toLowerCase();
      var soldQty = 0;
      if (sql != null && sql > 0 && qtyBySql.containsKey(sql)) {
        soldQty = qtyBySql[sql] ?? 0;
      } else if (name.isNotEmpty && nameCounts[name] == 1) {
        soldQty = qtyByName[name] ?? 0;
      }
      if (soldQty <= 0) continue;

      final stock = _stockOf(raw);
      // Only close the listing once paid orders have used up the listed stock.
      if (stock == null || soldQty < stock) continue;

      updates[docId] = {
        'sold': true,
        'isActive': false,
        'stockQuantity': 0,
        'quantity': 0,
      };
    }

    if (updates.isEmpty) return;

    final next = _items.map((raw) {
      final id = (raw['id'] ?? '').toString();
      final patch = updates[id];
      if (patch == null) return raw;
      return {...raw, ...patch};
    }).toList();
    _applyItemsToUi(next);

    for (final entry in updates.entries) {
      try {
        await _firestore.collection('marketplace_items').doc(entry.key).set(
          {
            ...entry.value,
            'updatedAt': FieldValue.serverTimestamp(),
          },
          SetOptions(merge: true),
        );
      } catch (e) {
        debugPrint('[My Items] mark sold ${entry.key} failed: $e');
      }
    }
  }

  Future<void> _applyEscrowEarnings(String uid) async {
    final refunds = await _completedRefundAmounts(uid);
    final escrow = await _earningsFromEscrow(uid, refunds);
    if (!mounted) return;
    if (!escrow.ok) return;
    setState(() {
      _freshEscrowEarnings = escrow.gross;
      _publishFreshEarnings();
      if (escrow.sold > _soldItems) {
        _soldItems = escrow.sold;
      }
    });
    unawaited(_persistEarningsCache(
      sold: _soldItems,
      earnings: _totalEarnings,
    ));
  }

  void _publishFreshEarnings() {
    final next = _freshEscrowEarnings;
    if (next == null) return;
    _totalEarnings = next < 0 ? 0 : next;
  }

  bool _refundIsDone(String status) {
    switch (status.trim().toLowerCase()) {
      case 'success':
      case 'successful':
      case 'completed':
      case 'complete':
      case 'paid':
      case 'refunded':
      case 'approved':
      case 'processed':
        return true;
      default:
        return false;
    }
  }

  double _asMoney(dynamic raw) {
    if (raw is num) return raw.toDouble();
    return double.tryParse('${raw ?? ''}'.replaceAll(',', '')) ?? 0;
  }

  Future<Map<String, double>>? _refundsInFlight;
  DateTime _refundsAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// Completed refunds keyed by order id and order number. Escrow and order
  /// stats both need this at startup, so one query is shared for a short while.
  Future<Map<String, double>> _completedRefundAmounts(String uid) {
    final fresh = DateTime.now().difference(_refundsAt) < const Duration(seconds: 30);
    if (_refundsInFlight != null && fresh) return _refundsInFlight!;
    _refundsAt = DateTime.now();
    return _refundsInFlight = _completedRefundAmountsNow(uid);
  }

  Future<Map<String, double>> _completedRefundAmountsNow(String uid) async {
    if (uid.isEmpty) return const {};
    try {
      final snap = await _firestore
          .collection('refund_requests')
          .where('merchantUid', isEqualTo: uid)
          .limit(300)
          .get();
      final out = <String, double>{};
      for (final doc in snap.docs) {
        final data = doc.data();
        final status = (data['status'] ?? '').toString();
        if (!_refundIsDone(status)) continue;
        final service = (data['serviceType'] ?? '').toString().trim().toLowerCase();
        if (service.isNotEmpty &&
            service != 'marketplace' &&
            service != 'promotion') {
          continue;
        }
        final amount = _asMoney(data['amount']);
        if (amount <= 0) continue;
        final keys = <String>{};
        for (final key in [data['orderId'], data['orderNumber']]) {
          final id = (key ?? '').toString().trim();
          if (id.isEmpty) continue;
          keys.add(id);
        }
        for (final id in keys) {
          out[id] = (out[id] ?? 0) + amount;
        }
      }
      return out;
    } catch (e) {
      debugPrint('Error loading refund amounts: $e');
      return const {};
    }
  }

  double _refundForKeys(Map<String, double> refunds, List<dynamic> keys) {
    var best = 0.0;
    for (final key in keys) {
      final id = (key ?? '').toString().trim();
      if (id.isEmpty) continue;
      final amount = refunds[id] ?? 0;
      if (amount > best) best = amount;
    }
    return best;
  }

  double _refundForOrder(OrderItem order, Map<String, double> refunds) {
    return _refundForKeys(refunds, [order.id, order.orderNumber]);
  }

  bool _orderFullyRefunded(OrderItem order, Map<String, double> refunds) {
    final refund = _refundForOrder(order, refunds);
    if (refund <= 0) return false;
    return refund + 0.5 >= order.lineTotal.toDouble();
  }

  bool _escrowWasRefunded(Map<String, dynamic> data) {
    final status = (data['status'] ?? '').toString().trim().toLowerCase();
    if (status == 'refunded' || status == 'cancelled' || status == 'canceled') {
      return true;
    }
    if (data['refundAfterRelease'] == true) return true;
    return _refundIsDone((data['refundStatus'] ?? '').toString());
  }

  Future<({int sold, double gross, bool ok})> _earningsFromEscrow(
    String uid,
    Map<String, double> refunds,
  ) async {
    if (uid.isEmpty) return (sold: 0, gross: 0.0, ok: false);
    try {
      QuerySnapshot<Map<String, dynamic>> snap;
      try {
        snap = await _firestore
            .collection('order_escrow')
            .where('merchantUid', isEqualTo: uid)
            .limit(400)
            .get(const GetOptions(source: Source.cache));
        if (snap.docs.isEmpty) {
          snap = await _firestore
              .collection('order_escrow')
              .where('merchantUid', isEqualTo: uid)
              .limit(400)
              .get();
        }
      } catch (_) {
        snap = await _firestore
            .collection('order_escrow')
            .where('merchantUid', isEqualTo: uid)
            .limit(400)
            .get();
      }
      int sold = 0;
      double gross = 0;
      for (final doc in snap.docs) {
        final data = doc.data();
        if (data['booksCleared'] == true || data['platformFeeCleared'] == true) {
          continue;
        }
        final status = (data['status'] ?? '').toString().trim().toLowerCase();
        if (status == 'cleared') continue;
        if (_escrowWasRefunded(data)) continue;
        final service = (data['serviceType'] ?? '').toString().trim().toLowerCase();
        if (service.isNotEmpty && service != 'marketplace') continue;
        final g = _asMoney(data['grossAmount']);
        final m = _asMoney(data['merchantAmount']);
        var amount = g > 0 ? g : m;
        if (amount <= 0) continue;
        final refund = _refundForKeys(
          refunds,
          [
            doc.id,
            data['orderId'],
            data['orderNumber'],
          ],
        );
        if (refund + 0.5 >= amount) continue;
        amount -= refund < 0 ? 0 : refund;
        sold++;
        gross += amount;
      }
      return (sold: sold, gross: gross, ok: true);
    } catch (e) {
      debugPrint('Error loading escrow earnings: $e');
      return (sold: 0, gross: 0.0, ok: false);
    }
  }

  Future<void> _hydrateEarningsFromPrefs() async {
    try {
      final uid = (_auth.currentUser?.uid ?? _uid).trim();
      if (uid.isEmpty) return;
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('$_prefsEarningsCachePrefix$uid');
      if (raw == null || raw.isEmpty) return;
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return;
      final earnings = (decoded['earnings'] is num)
          ? (decoded['earnings'] as num).toDouble()
          : double.tryParse('${decoded['earnings']}') ?? 0;
      final sold = (decoded['sold'] is int)
          ? decoded['sold'] as int
          : int.tryParse('${decoded['sold']}') ?? 0;
      if (!mounted) return;
      if (earnings <= 0 && sold <= 0) return;
      setState(() {
        if (earnings > 0) _totalEarnings = earnings;
        if (sold > 0) _soldItems = sold;
      });
    } catch (_) {}
  }

  Future<void> _persistEarningsCache({
    required int sold,
    required double earnings,
  }) async {
    try {
      final uid = (_auth.currentUser?.uid ?? _uid).trim();
      if (uid.isEmpty) return;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        '$_prefsEarningsCachePrefix$uid',
        jsonEncode({'sold': sold, 'earnings': earnings}),
      );
    } catch (_) {}
  }

  Future<void> _loadWalletBalance() async {
    try {
      final firebaseUid = _auth.currentUser?.uid ?? _uid;
      if (firebaseUid.trim().isEmpty) return;

      final ref = _firestore.collection('merchant_wallets').doc(firebaseUid);
      DocumentSnapshot<Map<String, dynamic>>? walletDoc;
      try {
        final cached = await ref.get(const GetOptions(source: Source.cache));
        if (cached.exists) walletDoc = cached;
      } catch (_) {}
      walletDoc ??= await ref.get();

      if (!walletDoc.exists || !mounted) return;

      final raw = walletDoc.data()?['balance'];
      double val = 0;
      if (raw is num) {
        val = raw.toDouble();
      } else {
        val = double.tryParse(raw?.toString() ?? '') ?? 0;
      }

      setState(() => _walletBalance = val);
    } catch (e) {
      debugPrint('Error loading wallet: $e');
    }
  }

  // ----------------- Nest/API userId (for sellerUserId filter) -----------------
  String? _cachedNestUserId;

  Future<String?> _getNestUserId({bool allowNetwork = true}) async {
    if (_cachedNestUserId != null && _cachedNestUserId!.isNotEmpty) {
      return _cachedNestUserId;
    }
    try {
      final sp = await SharedPreferences.getInstance();
      final cached = (sp.getString('merchant_nest_user_id') ?? '').trim();
      if (cached.isNotEmpty) {
        _cachedNestUserId = cached;
        return cached;
      }

      final token = sp.getString('jwt') ??
          sp.getString('token') ??
          sp.getString('jwt_token') ??
          sp.getString('authToken');

      if (token != null && token.trim().isNotEmpty) {
        final parts = token.split('.');
        if (parts.length == 3) {
          final payloadJson =
              utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
          final payload = jsonDecode(payloadJson) as Map<String, dynamic>;
          final rawId = payload['sub'] ?? payload['id'] ?? payload['userId'];
          if (rawId != null) {
            final id = rawId.toString();
            _cachedNestUserId = id;
            unawaited(sp.setString('merchant_nest_user_id', id));
            return id;
          }
        }
      }

      if (!allowNetwork) return null;

      final user = await _usersMe();
      if (user == null) return null;

      final rawId = user['id'] ?? user['userId'] ?? user['sub'];
      if (rawId == null) return null;
      final id = rawId.toString();
      _cachedNestUserId = id;
      unawaited(sp.setString('merchant_nest_user_id', id));
      return id;
    } catch (_) {
      return null;
    }
  }

  // ----------------- Items load + counts (total/active) -----------------
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _itemsByUidSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _itemsByNestSub;
  final Map<String, Map<String, dynamic>> _itemsByUidDocs = {};
  final Map<String, Map<String, dynamic>> _itemsByNestDocs = {};
  String _itemsListenUid = '';
  String _itemsListenNest = '';
  Timer? _mergeItemsTimer;

  void _onItemsSnapshot(
    QuerySnapshot<Map<String, dynamic>> snap,
    Map<String, Map<String, dynamic>> into,
  ) {
    for (final change in snap.docChanges) {
      final doc = change.doc;
      if (change.type == DocumentChangeType.removed) {
        into.remove(doc.id);
      } else {
        into[doc.id] = {...?doc.data(), 'id': doc.id};
      }
    }
    // An empty local cache on first open isn't "no items" — wait for the server.
    if (snap.metadata.isFromCache && snap.docs.isEmpty) {
      Future<void>.delayed(const Duration(seconds: 5), () {
        if (mounted && _loadingItems) setState(() => _loadingItems = false);
      });
      return;
    }
    // Both listeners fire together on open; merge once.
    _mergeItemsTimer?.cancel();
    _mergeItemsTimer = Timer(const Duration(milliseconds: 60), _mergeListenedItems);
  }

  void _onItemsListenError(Object e) {
    debugPrint('Error loading items: $e');
    if (mounted && _loadingItems) setState(() => _loadingItems = false);
  }

  static int _itemCreatedMillis(Map<String, dynamic> it) {
    final raw = it['createdAt'];
    if (raw is Timestamp) return raw.millisecondsSinceEpoch;
    if (raw is num) return raw.toInt();
    if (raw is String) return DateTime.tryParse(raw)?.millisecondsSinceEpoch ?? 0;
    return 0;
  }

  void _mergeListenedItems() {
    final merged = <String, Map<String, dynamic>>{
      ..._itemsByNestDocs,
      ..._itemsByUidDocs,
    };
    final list = merged.values.toList()
      ..sort((a, b) => _itemCreatedMillis(b).compareTo(_itemCreatedMillis(a)));
    _applyItemsToUi(list);
  }

  /// When [showLoading] is false, keeps the current grid visible while refreshing
  /// in the background (used by periodic updates so the UI stays stable).
  Future<void> _loadItems({bool showLoading = true}) async {
    // Prefer showing cached items G?? never blank the grid while refreshing.
    if (_items.isEmpty) {
      _hydrateItemsFromLocalCache();
      if (_items.isEmpty) await _hydrateItemsFromPrefsCache();
    }

    if (showLoading && mounted && _items.isEmpty) {
      setState(() => _loadingItems = true);
    } else if (mounted && _items.isNotEmpty) {
      setState(() => _loadingItems = false);
    }

    try {
      // Live listeners: first event comes from the local cache, later ones
      // carry only changed listings instead of re-downloading every item.
      final firebaseUid = (_auth.currentUser?.uid ?? _uid).trim();
      if (firebaseUid.isNotEmpty &&
          (_itemsByUidSub == null || _itemsListenUid != firebaseUid)) {
        await _itemsByUidSub?.cancel();
        _itemsByUidDocs.clear();
        _itemsListenUid = firebaseUid;
        _itemsByUidSub = _firestore
            .collection('marketplace_items')
            .where('merchantId', isEqualTo: firebaseUid)
            .snapshots()
            .listen(
              (snap) => _onItemsSnapshot(snap, _itemsByUidDocs),
              onError: _onItemsListenError,
            );
      }

      final nestId =
          (await _getNestUserId(allowNetwork: false) ??
                  await _getNestUserId(allowNetwork: true) ??
                  '')
              .trim();
      if (!mounted) return;
      if (nestId.isNotEmpty &&
          (_itemsByNestSub == null || _itemsListenNest != nestId)) {
        await _itemsByNestSub?.cancel();
        _itemsByNestDocs.clear();
        _itemsListenNest = nestId;
        _itemsByNestSub = _firestore
            .collection('marketplace_items')
            .where('sellerUserId', isEqualTo: nestId)
            .snapshots()
            .listen(
              (snap) => _onItemsSnapshot(snap, _itemsByNestDocs),
              onError: _onItemsListenError,
            );
      }
    } catch (e) {
      debugPrint('Error loading items: $e');
      if (!mounted) return;
      if (showLoading && _items.isEmpty) {
        setState(() {
          _items = [];
          _totalItems = 0;
          _activeItems = 0;
          _loadingItems = false;
        });
      } else if (mounted) {
        setState(() => _loadingItems = false);
      }
    }
  }

  List<Map<String, dynamic>> _filteredItems() {
    final q = _searchQuery.trim().toLowerCase();
    return _items.where((it) {
      final name = (it['name'] ?? '').toString().toLowerCase();
      final cat = (it['category'] ?? 'other').toString().toLowerCase();
      final review = _itemReviewStatus(it);
      final sold = _itemIsSold(it);
      final active =
          it['isActive'] == true && review == 'approved' && !sold;

      final okQ = q.isEmpty || name.contains(q);
      final okCat = (_filterCategory == 'all') || cat == _filterCategory;
      final okStatus = (_filterStatus == 'all') ||
          (_filterStatus == 'active' && active) ||
          (_filterStatus == 'sold' && sold) ||
          (_filterStatus == 'inactive' &&
              review == 'approved' &&
              it['isActive'] != true &&
              !sold) ||
          (_filterStatus == 'pending' &&
              (review == 'pending' || review.isEmpty && it['isActive'] != true)) ||
          (_filterStatus == 'rejected' && review == 'rejected');

      return okQ && okCat && okStatus;
    }).toList();
  }

  /// `pending` | `approved` | `rejected` | '' (legacy).
  static String _itemReviewStatus(Map<String, dynamic> it) {
    final raw = (it['reviewStatus'] ?? '').toString().trim().toLowerCase();
    if (raw == 'pending' || raw == 'approved' || raw == 'rejected') return raw;
    // Legacy listings without reviewStatus: treat active as approved.
    if (it['isActive'] == true) return 'approved';
    return '';
  }

  static int? _stockOf(Map<String, dynamic> it) {
    final raw = it['stockQuantity'] ?? it['quantity'] ?? it['stock'];
    if (raw == null) return null;
    if (raw is num) return raw.toInt();
    final text = raw.toString().trim();
    if (text.isEmpty) return null;
    return int.tryParse(text);
  }

  /// Sold when stock is finished or the listing was explicitly marked sold.
  /// A paused listing with stock left stays Inactive, not Sold.
  static bool _itemIsSold(Map<String, dynamic> it) {
    final flag = it['sold'] ?? it['isSold'];
    if (flag == true || flag == 1 || '${flag}'.toLowerCase() == 'true') {
      return true;
    }
    final stock = _stockOf(it);
    return stock != null && stock <= 0;
  }

  static bool _countsAsActiveListing(Map<String, dynamic> it) =>
      it['isActive'] == true && !_itemIsSold(it);

  static String _reviewLabel(Map<String, dynamic> it) {
    if (_itemIsSold(it)) return 'Sold';
    final review = _itemReviewStatus(it);
    if (review == 'pending') return 'Under review';
    if (review == 'rejected') return 'Rejected';
    if (it['isActive'] == true) return 'Live';
    return 'Inactive';
  }

  static Color _reviewColor(Map<String, dynamic> it) {
    if (_itemIsSold(it)) return const Color(0xFFB71C1C);
    final review = _itemReviewStatus(it);
    if (review == 'pending') return Colors.orange;
    if (review == 'rejected') return Colors.red;
    if (it['isActive'] == true) return Colors.green;
    return Colors.grey;
  }

  // ----------------- Pull-to-refresh -----------------
  Future<void> _refreshAll() async {
    _hydrateFromFirebaseAuth();
    _docReads.clear();
    _usersMeRead = null;
    _refundsInFlight = null;
    await Future.wait<void>([
      _pullPhoneAndProfileFromFirestore(),
      _loadKycStatus(),
      _ensureBusinessName(),
      _fetchCurrentUserMe(),
      _loadMerchantData(),
      _loadWalletBalance(),
      _loadItems(showLoading: false),
      _loadOrderStats(),
    ]);
    if (_merchantProfileUrl.trim().isNotEmpty) {
      unawaited(_warmProfilePhotoCache(_merchantProfileUrl));
    }
  }

  Future<void> _loadKycStatus() async {
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    if (uid.isEmpty) return;
    try {
      final snap = await KycGate.loadStatus(uid: uid);
      if (!mounted) return;
      setState(() {
        _kycStatus = snap.status;
        _kycRejectionReason = snap.rejectionReason;
      });
    } catch (e) {
      if (kDebugMode) debugPrint('KYC status load failed: $e');
    }
  }

  Future<void> _openKycVerification() async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const KycVerificationScreen()),
    );
    if (!mounted) return;
    _docReads.clear();
    await _loadKycStatus();
  }

  // ----------------- Profile image helpers -----------------
  ImageProvider? _profileImageProvider() {
    final local = _localPhotoPath;
    if (!kIsWeb && local != null && local.isNotEmpty) {
      try {
        final f = File(local);
        if (f.existsSync()) return FileImage(f);
      } catch (_) {}
    }
    final s = _merchantProfileUrl.trim();
    if (s.isEmpty) return null;
    if (s.startsWith('http://') || s.startsWith('https://')) {
      return CachedNetworkImageProvider(s);
    }
    if (_profileMemoryImage != null && _profileMemorySource == s) {
      return _profileMemoryImage;
    }
    try {
      final bytes = base64Decode(s);
      _profileMemorySource = s;
      return _profileMemoryImage = MemoryImage(bytes);
    } catch (_) {
      return null;
    }
  }

  String? _profileMemorySource;
  MemoryImage? _profileMemoryImage;

  // ----------------- Profile photo (Firebase Storage) -----------------
  void _showPhotoSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);
                _pickAndUploadProfile(ImageSource.camera);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: _brandOrange,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.photo_camera_outlined,
                            color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Take a photo',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF222222),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.pop(context);
                _pickAndUploadProfile(ImageSource.gallery);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: Color(0xFF1E88E5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.photo_library_outlined,
                            color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Choose from gallery',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF222222),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (_merchantProfileUrl.trim().isNotEmpty)
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                  _removeProfilePhoto();
                },
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.remove_circle_outline,
                              color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            'Remove current photo',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF222222),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _viewProfilePhoto() {
    final img = _profileImageProvider();
    if (img == null) return;

    showDialog(
      context: context,
      builder: (_) => Dialog(
        insetPadding: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            children: [
              AspectRatio(
                aspectRatio: 1,
                child: Image(image: img, fit: BoxFit.cover),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: Material(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(999),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(999),
                    onTap: () => Navigator.pop(context),
                    child: const Padding(
                      padding: EdgeInsets.all(8),
                      child: Icon(Icons.close, color: Colors.white),
                    ),
                  ),
                ),
              ),
              if (_merchantProfileUrl.trim().isNotEmpty)
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 16,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.red.shade700,
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: () async {
                      final confirmed = await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text('Remove profile photo?'),
                          content: const Text(
                            'This will remove your current profile picture.',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text('Cancel'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              child: const Text(
                                'Remove',
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        ),
                      );
                      if (confirmed != true) return;
                      await _removeProfilePhoto();
                      if (!mounted) return;
                      Navigator.of(context).pop();
                    },
                    icon: const Icon(Icons.delete_outline),
                    label: const Text(
                      'Remove profile photo',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickAndUploadProfile(ImageSource src) async {
    final user = _auth.currentUser;
    if (user == null) return;

    final file = await _picker.pickImage(
      source: src,
      maxWidth: 1400,
      imageQuality: 85,
    );
    if (file == null) return;

    try {
      setState(() => _profileUploading = true);
      String url;
      final pickedBytes = await file.readAsBytes();

      // Prefer backend upload (works when Firebase Storage returns 404 / App Check).
      try {
        url = await _uploadProfileViaBackend(file);
      } catch (backendErr) {
        debugPrint('Backend profile upload failed: $backendErr');
        try {
          url = await _uploadProfileToFirebaseStorage(user.uid, file);
        } on FirebaseException catch (e) {
          if ((e.code == 'object-not-found' || e.code == 'unknown') && (e.message?.contains('404') == true)) {
            url = await _uploadProfileViaBackend(file);
          } else {
            rethrow;
          }
        }
      }

      await user.updatePhotoURL(url);
      await user.reload();

      await _firestore.collection('users').doc(user.uid).set({
        'profilePicture': url,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profilepicture', url);

      // Persist bytes locally so the avatar shows instantly next time.
      final local = await ProfilePhotoCache.saveBytes(
        pickedBytes,
        remoteUrl: url,
      );

      if (!mounted) return;
      setState(() {
        _merchantProfileUrl = url;
        _localPhotoPath = local?.path ?? _localPhotoPath;
      });

      _toastOk('Profile picture updated');
    } on FirebaseException catch (e) {
      debugPrint('Profile upload error: ${e.code} ${e.message}');
      if (!mounted) return;
      try {
        final url = await _uploadProfileViaBackend(file);
        if (url.isNotEmpty) {
          final u = _auth.currentUser;
          if (u != null) {
            await u.updatePhotoURL(url);
            await u.reload();
            await _firestore.collection('users').doc(u.uid).set({
              'profilePicture': url,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('profilepicture', url);
            final bytes = await file.readAsBytes();
            final local = await ProfilePhotoCache.saveBytes(
              bytes,
              remoteUrl: url,
            );
            setState(() {
              _merchantProfileUrl = url;
              _localPhotoPath = local?.path ?? _localPhotoPath;
            });
            _toastOk('Profile picture updated');
            return;
          }
        }
      } catch (fallbackErr) {
        debugPrint('Backend fallback failed: $fallbackErr');
      }
      if (e.code == 'object-not-found' || (e.message ?? '').contains('404')) {
        _toastErr('Upload failed. Check network and that the server is running.');
      } else {
        _toastErr('Failed to upload photo. Please try again.');
      }
    } catch (e) {
      debugPrint('Profile upload error: $e');
      if (!mounted) return;
      _toastErr('Failed to upload photo. Please try again.');
    } finally {
      if (mounted) setState(() => _profileUploading = false);
    }
  }

  /// Upload via backend POST /vero/users/me/profile-picture. Uses a fresh ID token to avoid auth/id-token-expired.
  Future<String> _uploadProfileViaBackend(XFile file) async {
    String bearer = await _getBearerTokenForApi(forceRefresh: true) ?? '';
    if (bearer.isEmpty) throw Exception('Not authenticated');
    final uri = ApiConfig.endpoint('/users/me/profile-picture');
    final bytes = await file.readAsBytes();
    final mimeType = lookupMimeType(file.name, headerBytes: bytes) ?? 'image/jpeg';
    final parts = mimeType.split('/');
    final contentType = parts.length == 2 ? MediaType(parts[0], parts[1]) : null;

    Future<http.StreamedResponse> sendRequest(String token) async {
      final req = http.MultipartRequest('POST', uri)
        ..headers['Authorization'] = 'Bearer $token'
        ..files.add(http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: file.name.isNotEmpty ? file.name : 'profile.jpg',
          contentType: contentType,
        ));
      return req.send();
    }

    var sent = await sendRequest(bearer);
    var resp = await http.Response.fromStream(sent);

    if (resp.statusCode == 401) {
      bearer = await _getBearerTokenForApi(forceRefresh: true) ?? '';
      if (bearer.isEmpty) throw Exception('Session expired. Please sign in again.');
      sent = await sendRequest(bearer);
      resp = await http.Response.fromStream(sent);
    }

    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      if (resp.statusCode == 404) throw Exception('Profile picture endpoint not found');
      if (resp.statusCode == 401) throw Exception('Session expired. Please sign in again.');
      throw Exception('Upload failed (${resp.statusCode}) ${resp.body}');
    }
    final body = jsonDecode(resp.body);
    final data = (body is Map && body['data'] is Map)
        ? body['data'] as Map
        : (body is Map ? Map<String, dynamic>.from(body) : <String, dynamic>{});
    final url = (data['profilepicture'] ?? data['profilePicture'] ?? data['url'])?.toString();
    if (url == null || url.isEmpty) throw Exception('No URL in response');
    return url;
  }

  /// Upload profile image to Firebase Storage.
  /// Uses a single path segment (profile_photos/uid_timestamp.ext) to avoid 404 with nested refs.
  Future<String> _uploadProfileToFirebaseStorage(String uid, XFile file) async {
    final rawExt = file.name.contains('.') ? file.name.split('.').last : 'jpg';
    final ext = rawExt.isEmpty || rawExt.length > 4 ? 'jpg' : rawExt;
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final path = 'profile_photos/${uid}_$timestamp.$ext';
    final ref = FirebaseStorage.instance.ref().child(path);

    final bytes = await file.readAsBytes();
    final mime = lookupMimeType(file.name, headerBytes: bytes) ?? 'image/jpeg';
    await ref.putData(bytes, SettableMetadata(contentType: mime));
    return await ref.getDownloadURL();
  }

  Future<void> _removeProfilePhoto() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      setState(() => _profileUploading = true);

      await user.updatePhotoURL(null);
      await user.reload();
      if (_auth.currentUser?.photoURL == null || _auth.currentUser!.photoURL!.isEmpty) {
        if (mounted) setState(() => _merchantProfileUrl = '');
      }

      await _firestore.collection('users').doc(user.uid).set({
        'profilePicture': '',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profilepicture', '');
      await ProfilePhotoCache.clear();

      if (!mounted) return;
      setState(() {
        _merchantProfileUrl = '';
        _localPhotoPath = null;
      });

      _toastOk('Profile picture removed');
    } catch (e) {
      debugPrint('Remove photo error: $e');
      if (!mounted) return;
      _toastErr('Failed to remove photo. Please try again.');
    } finally {
      if (mounted) setState(() => _profileUploading = false);
    }
  }

  // ----------------- G?? More photos helpers -----------------
  Future<void> _pickMorePhotos() async {
    try {
      final files = await _picker.pickMultiImage(
        imageQuality: 80,
        maxWidth: 1600,
      );

      if (files.isEmpty) return;

      final remaining = _maxGalleryPhotos - _gallery.length;
      if (remaining <= 0) {
        if (!mounted) return;
        _toastErr('You can add up to $_maxGalleryPhotos photos.');
        return;
      }

      final toAdd = files.take(remaining).toList();
      for (final x in toAdd) {
        final bytes = await x.readAsBytes();
        _gallery.add(
          LocalMedia(
            bytes: bytes,
            filename: x.name,
            mime: lookupMimeType(x.name, headerBytes: bytes),
          ),
        );
      }

      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('Pick more photos error: $e');
      if (!mounted) return;
      _toastErr('Could not pick photos. Please try again.');
    }
  }

  void _removeGalleryAt(int index) {
    if (index < 0 || index >= _gallery.length) return;
    setState(() => _gallery.removeAt(index));
  }

  String _firestoreWriteErrorMessage(Object e) {
    if (e is FirebaseException) {
      switch (e.code) {
        case 'permission-denied':
          return 'You donG??t have permission to post this listing. Please sign in again and try once more.';
        case 'unauthenticated':
          return 'Please sign in to post on Marketplace.';
        case 'unavailable':
        case 'deadline-exceeded':
          return 'WeG??re having trouble connecting. Check your internet and try again.';
        case 'resource-exhausted':
          return 'Too many requests right now. Please wait a moment and try again.';
        default:
          return 'CouldnG??t post your listing. Please try again.';
      }
    }
    if (e is StateError) {
      final msg = e.message.trim();
      if (msg.isNotEmpty &&
          !msg.toLowerCase().contains('firestore') &&
          !msg.toLowerCase().contains('firebase')) {
        return msg;
      }
    }
    return 'CouldnG??t post your listing. Please try again.';
  }

  // ----------------- CREATE item (fast path) -----------------
  Future<Uint8List> _compressForMarketplaceUpload(Uint8List raw) async {
    // Skip CPU work when already small enough for a quick upload.
    if (raw.lengthInBytes <= 220000) return raw;
    try {
      return await compute(_compressMarketplaceBytesIsolate, raw);
    } catch (_) {
      return raw;
    }
  }

  Future<bool> _confirmListingAccuracy() async {
    const strong = TextStyle(
      fontWeight: FontWeight.w800,
      color: Color(0xFF101010),
      height: 1.4,
      fontSize: 14,
    );
    const red = TextStyle(
      fontWeight: FontWeight.w800,
      color: Color(0xFFD32F2F),
      height: 1.4,
      fontSize: 14,
    );
    const body = TextStyle(
      fontWeight: FontWeight.w600,
      color: Color(0xFF374151),
      height: 1.4,
      fontSize: 14,
    );
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        insetPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: Color(0xFFE65100)),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Warning',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        color: Color(0xFF101010),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Before you confirm your listing',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 15,
                  color: Color(0xFF101010),
                ),
              ),
              const SizedBox(height: 12),
              const Text.rich(
                TextSpan(
                  style: body,
                  children: [
                    TextSpan(text: 'Check that your '),
                    TextSpan(
                      text: 'photos, description and product details accurately match',
                      style: strong,
                    ),
                    TextSpan(text: ' what you are selling.'),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Text.rich(
                TextSpan(
                  style: body,
                  children: [
                    TextSpan(text: 'Buyers have the '),
                    TextSpan(
                      text: 'right to return products that do not match your listing',
                      style: red,
                    ),
                    TextSpan(text: '.'),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Text.rich(
                TextSpan(
                  style: body,
                  children: [
                    TextSpan(
                      text: 'You are responsible for your products’ quality and condition. ',
                      style: strong,
                    ),
                    TextSpan(
                      text: 'Vero360 is not responsible for your product quality.',
                      style: red,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Text.rich(
                TextSpan(
                  style: body,
                  children: [
                    TextSpan(text: 'By confirming, you declare that '),
                    TextSpan(text: 'your listing is accurate', style: strong),
                    TextSpan(text: ' and accept these responsibilities.'),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Go Back & Edit',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                          color: Color(0xFF374151),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: FilledButton.styleFrom(
                        backgroundColor: _brandOrange,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Confirm & Continue',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return confirmed == true;
  }

  Future<void> _create() async {
    // Sync lock BEFORE any await so one tap cannot post twice on slow networks.
    if (_submitting) return;

    if (_cover == null) {
      _toastErr('Please pick a cover photo');
      return;
    }
    if (_name.text.isEmpty || _price.text.isEmpty || _location.text.isEmpty) {
      _toastErr('Please fill all required fields');
      return;
    }

    final stockRaw = _stock.text.trim();
    final stock = int.tryParse(stockRaw);
    if (stockRaw.isEmpty || stock == null || stock < 1) {
      _toastErr('Enter how many items you have in stock (at least 1)');
      return;
    }
    _stockQty = stock;

    final blockReason = MarketplaceModeration.clientBlockReason(
      title: _name.text,
      description: _desc.text,
    );
    if (blockReason != null) {
      _toastErr(blockReason);
      return;
    }

    final accepted = await _confirmListingAccuracy();
    if (!accepted || !mounted) return;
    if (_submitting) return;
    _submitting = true;
    if (mounted) setState(() {});

    try {

      final user = _auth.currentUser;
      unawaited(AuthHandler.refreshFirebaseTokenIfSignedIn());

      final firebaseUid = user?.uid ?? _uid;
      if (firebaseUid.trim().isEmpty) {
        _toastErr('Missing user id G?? sign in and try again.');
        return;
      }
      // Never block posting on /users/me — use cache/JWT only.
      final sellerId = await _getNestUserId(allowNetwork: false);
      final merchantDisplay = _displayBusinessName();
      final effectiveSellerId =
          (sellerId != null && sellerId.trim().isNotEmpty)
              ? sellerId.trim()
              : firebaseUid;

      final svc = MarketplaceService();
      final uploadToken = await AuthHandler.getTokenForApi();

      // Shrink photos off the UI isolate, then upload them in parallel.
      final coverRaw = _cover!.bytes;
      final galleryRaw = List<LocalMedia>.from(_gallery);
      final compressedList = await Future.wait<Uint8List>([
        _compressForMarketplaceUpload(coverRaw),
        ...galleryRaw.map((m) => _compressForMarketplaceUpload(m.bytes)),
      ]);
      final coverBytes = compressedList.first;
      final galleryBytes = compressedList.length > 1
          ? compressedList.sublist(1)
          : <Uint8List>[];

      String? coverUrl;
      String? coverBase64;
      final galleryUrls = <String>[];
      final galleryBase64 = <String>[];

      try {
        final uploadFutures = <Future<String>>[
          svc.uploadBytes(
            coverBytes,
            filename: _cover!.filename ?? 'cover.jpg',
            mimeType: 'image/jpeg',
            token: uploadToken,
            timeout: const Duration(seconds: 30),
          ),
          for (var i = 0; i < galleryRaw.length; i++)
            svc.uploadBytes(
              galleryBytes[i],
              filename: galleryRaw[i].filename.isNotEmpty
                  ? galleryRaw[i].filename
                  : 'gallery_$i.jpg',
              mimeType: 'image/jpeg',
              token: uploadToken,
              timeout: const Duration(seconds: 30),
            ),
        ];
        final uploaded = await Future.wait(uploadFutures);
        coverUrl = uploaded.first;
        if (galleryRaw.isNotEmpty) {
          galleryUrls.addAll(uploaded.sublist(1));
        }
      } catch (uploadErr) {
        debugPrint(
            'Backend upload failed, saving to Firestore as base64: $uploadErr');
        if (coverBytes.length > 450000) {
          throw StateError(
            'Image upload failed and the photo is too large to save offline. '
            'Check internet and that your backend server is running.',
          );
        }
        coverBase64 = base64Encode(coverBytes);
        for (final bytes in galleryBytes) {
          if (bytes.length > 200000) continue;
          galleryBase64.add(base64Encode(bytes));
        }
      }

      final data = <String, dynamic>{
        'name': _name.text.trim(),
        'price': parseMwkInput(_price.text) ?? 0,
        if (coverUrl != null) 'imageUrl': coverUrl,
        if (coverBase64 != null) 'image': coverBase64,
        if (galleryUrls.isNotEmpty) 'galleryUrls': galleryUrls,
        if (galleryBase64.isNotEmpty) 'gallery': galleryBase64,
        if (_videos.isNotEmpty) 'videos': await _uploadListingVideos(svc, uploadToken),
        'description': _desc.text.trim().isEmpty
            ? null
            : DescriptionContactMask.mask(_desc.text.trim()),
        'location': _location.text.trim(),
        'isActive': false,
        'reviewStatus': 'pending',
        'category': _category ?? 'other',
        'createdAt': FieldValue.serverTimestamp(),
        'sellerUserId': effectiveSellerId,
        'merchantId': firebaseUid,
        'firebaseUid': firebaseUid,
        if (sellerId != null)
          'merchantBackendId': int.tryParse(sellerId.trim()),
        'merchantName': merchantDisplay,
        'serviceType': 'marketplace',
        'stockQuantity': _stockQty,
        'quantity': _stockQty,
        'postToFacebook': _postToFacebook,
      };

      final docRef =
          await _firestore.collection('marketplace_items').add(data);
      debugPrint('Firestore write OK G?? marketplace_items (pending review)');

      // Visual hashes for duplicate detection — never block the submit UX.
      final hashCover = coverBytes;
      final hashGallery = List<Uint8List>.from(galleryBytes);
      unawaited(() async {
        try {
          final coverHash = await svc.computeVisualHash(hashCover);
          final gHashes = <String>[];
          for (final b in hashGallery) {
            final h = await svc.computeVisualHash(b);
            if (h != null) gHashes.add(h);
          }
          final imageHashes = <String>{
            if (coverHash != null) coverHash,
            ...gHashes,
          }.toList();
          if (imageHashes.isEmpty) return;
          await docRef.set({
            if (coverHash != null) 'imageHash': coverHash,
            if (gHashes.isNotEmpty) 'galleryHashes': gHashes,
            'imageHashes': imageHashes,
          }, SetOptions(merge: true));
        } catch (_) {}
      }());

      if (!mounted) return;
      ToastHelper.showCustomToast(
        context,
        'Submitted for review. We’ll notify you when it’s live.',
        isSuccess: true,
        errorMessage: 'Submitted',
        showFacebook: _postToFacebook,
        facebookMessage: _postToFacebook
            ? 'Once approved, we’ll also share this on the Vero360 Facebook Page.'
            : null,
      );

      final boostItem = <String, dynamic>{
        ...data,
        'id': docRef.id,
        'name': data['name'],
      };
      await Future<void>.delayed(const Duration(milliseconds: 450));
      if (mounted) {
        await MarketplacePromoteService.presentPostSuccessBoostPrompt(
          context: context,
          itemId: docRef.id,
          item: boostItem,
        );
      }

      _name.clear();
      _price.clear();
      _location.clear();
      _desc.clear();
      _stock.text = '1';
      _stockQty = 1;
      _cover = null;
      _gallery.clear();
      _isActive = true;
      _postToFacebook = true;
      _category = 'other';

      setState(() {});
      unawaited(_loadItems(showLoading: false));
      _marketplaceTabs.animateTo(2);
    } on FirebaseException catch (e) {
      debugPrint('Create item Firestore error: ${e.code} ${e.message}');
      if (!mounted) return;
      _toastErr(_firestoreWriteErrorMessage(e));
    } catch (e) {
      debugPrint('Create item error: $e');
      if (!mounted) return;
      _toastErr(_firestoreWriteErrorMessage(e));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Future<void> _deleteItem(Map<String, dynamic> item) async {
    final itemName = (item['name'] ?? item['title'] ?? 'item').toString().trim();
    final displayName = itemName.isEmpty ? 'this item' : itemName;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete item'),
        content: Text('Delete "$displayName"? This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _busyRow = true);
    try {
      final id = item['id'] as String;
      await _firestore.collection('marketplace_items').doc(id).delete();
      _items.removeWhere((e) => e['id'] == id);
      unawaited(_persistItemsCache(_items));

      if (!mounted) return;
      _toastOk('Deleted "$displayName"');

      setState(() {
        _totalItems = _items.length;
        _activeItems = _items.where(_countsAsActiveListing).length;
      });
    } catch (e) {
      debugPrint('Delete item error: $e');
      if (!mounted) return;
      _toastErr('Delete failed. Please try again.');
    } finally {
      if (mounted) setState(() => _busyRow = false);
    }
  }

  // G?? FIXED: no parent setState while sheet is closing + no crash after save
  Future<void> _openEditItemSheet(Map<String, dynamic> item) async {
    final id = (item['id'] ?? '').toString().trim();
    if (id.isEmpty) return;

    _sheetOpen = true;

    final rootCtx = context;

    final nameCtrl =
        TextEditingController(text: (item['name'] ?? '').toString());
    final priceCtrl = TextEditingController(
      text: formatMwkInput(_asNum(item['price'])),
    );
    final locationCtrl =
        TextEditingController(text: (item['location'] ?? '').toString());
    final descCtrl =
        TextEditingController(text: (item['description'] ?? '').toString());
    final stockCtrl = TextEditingController(
      text: (() {
        final raw = item['stockQuantity'] ?? item['quantity'] ?? item['stock'];
        final n = raw is num ? raw.toInt() : int.tryParse('${raw ?? ''}');
        return '${(n == null || n < 1) ? 1 : n}';
      })(),
    );
    int stockQty = int.tryParse(stockCtrl.text) ?? 1;

    String category = (item['category'] ?? 'other').toString().toLowerCase().trim();
    if (category == 'food' || !_kCategories.contains(category)) {
      category = 'other';
    }
    bool isActive = item['isActive'] == true;

    LocalMedia? newCover;

    final savedName = await showModalBottomSheet<String>(
      context: rootCtx,
      isScrollControlled: true,
      useSafeArea: true,
      useRootNavigator: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetCtx) {
        bool saving = false;

        return StatefulBuilder(
          builder: (sheetCtx, setSheet) {
            final bottomInset = MediaQuery.of(sheetCtx).viewInsets.bottom;

            Future<void> pickNewCoverFrom(ImageSource src) async {
              final x = await _picker.pickImage(
                source: src,
                maxWidth: 1600,
                imageQuality: 80,
              );
              if (x == null) return;

              final bytes = await x.readAsBytes();
              setSheet(() {
                newCover = LocalMedia(
                  bytes: bytes,
                  filename: x.name,
                  mime: lookupMimeType(x.name, headerBytes: bytes),
                );
              });
            }

            void showEditCoverSource() {
              showModalBottomSheet(
                context: sheetCtx,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                ),
                builder: (sourceSheetContext) => SafeArea(
                  child: Wrap(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(sourceSheetContext);
                          pickNewCoverFrom(ImageSource.camera);
                        },
                        borderRadius: BorderRadius.circular(16),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade50,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.grey.shade200),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFFF8A00),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.photo_camera_outlined,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                const Expanded(
                                  child: Text(
                                    'Take a photo',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF222222),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pop(sourceSheetContext);
                          pickNewCoverFrom(ImageSource.gallery);
                        },
                        borderRadius: BorderRadius.circular(16),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade50,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.grey.shade200),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF1E88E5),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.photo_library_outlined,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                const Expanded(
                                  child: Text(
                                    'Choose from gallery',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF222222),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }

            Future<void> save() async {
              if (saving) return;

              FocusScope.of(sheetCtx).unfocus();

              final n = nameCtrl.text.trim();
              final p = parseMwkInput(priceCtrl.text) ?? 0;
              final loc = locationCtrl.text.trim();
              final stockRaw = stockCtrl.text.trim();
              final stock = int.tryParse(stockRaw);

              if (n.isEmpty || p <= 0 || loc.isEmpty) {
                ToastHelper.showCustomToast(
                  rootCtx,
                  'Fill name, price and location',
                  isSuccess: false,
                  errorMessage: '',
                );
                return;
              }
              if (stockRaw.isEmpty || stock == null || stock < 1) {
                ToastHelper.showCustomToast(
                  rootCtx,
                  'Enter quantity in stock (at least 1)',
                  isSuccess: false,
                  errorMessage: '',
                );
                return;
              }
              stockQty = stock;

              setSheet(() => saving = true);

              try {
                final blockReason = MarketplaceModeration.clientBlockReason(
                  title: n,
                  description: descCtrl.text,
                );
                if (blockReason != null) {
                  ToastHelper.showCustomToast(
                    rootCtx,
                    blockReason,
                    isSuccess: false,
                    errorMessage: '',
                  );
                  setSheet(() => saving = false);
                  return;
                }

                final prevReview = _itemReviewStatus(item);
                final patch = <String, dynamic>{
                  'name': n,
                  'price': p,
                  'location': loc,
                  'category': category,
                  'stockQuantity': stockQty,
                  'quantity': stockQty,
                  'updatedAt': FieldValue.serverTimestamp(),
                };
                final desc = DescriptionContactMask.mask(descCtrl.text.trim());
                if (desc.isEmpty) {
                  patch['description'] = FieldValue.delete();
                } else {
                  patch['description'] = desc;
                }

                if (prevReview == 'rejected' || prevReview == 'pending') {
                  // Resubmit for auto-moderation.
                  patch['isActive'] = false;
                  patch['reviewStatus'] = 'pending';
                  patch['rejectedReason'] = FieldValue.delete();
                  patch['moderationResubmittedAt'] =
                      FieldValue.serverTimestamp();
                } else {
                  // Already approved: merchant can pause/unpause.
                  patch['isActive'] = isActive;
                }

                if (newCover != null) {
                  final svc = MarketplaceService();
                  try {
                    final coverUrl = await svc.uploadBytes(
                      newCover!.bytes,
                      filename: (newCover!.filename ?? '').trim().isEmpty
                          ? 'cover.jpg'
                          : newCover!.filename!,
                      mimeType: newCover!.mime,
                    );
                    patch['imageUrl'] = coverUrl;
                    patch['image'] = FieldValue.delete();
                    patch['photo'] = FieldValue.delete();
                    patch['picture'] = FieldValue.delete();
                  } catch (uploadErr) {
                    debugPrint('Edit cover upload failed: $uploadErr');
                    ToastHelper.showCustomToast(
                      rootCtx,
                      'Could not upload the new cover photo. Check your internet and try again.',
                      isSuccess: false,
                      errorMessage: '',
                    );
                    setSheet(() => saving = false);
                    return;
                  }
                  final coverHash =
                      await svc.computeVisualHash(newCover!.bytes);
                  if (coverHash != null) {
                    patch['imageHash'] = coverHash;
                    patch['imageHashes'] = FieldValue.arrayUnion([coverHash]);
                  }
                  if (prevReview == 'approved') {
                    patch['isActive'] = false;
                    patch['reviewStatus'] = 'pending';
                  }
                }

                await _firestore.collection('marketplace_items').doc(id).update(
                      patch,
                    );

                if (Navigator.of(sheetCtx).canPop()) {
                  Navigator.of(sheetCtx).pop(n);
                }
              } catch (e) {
                debugPrint('Update item error: $e');
                ToastHelper.showCustomToast(
                  rootCtx,
                  'Update failed. Please try again.',
                  isSuccess: false,
                  errorMessage: '',
                );
                try {
                  setSheet(() => saving = false);
                } catch (_) {}
              }
            }

            final coverWidget = newCover != null
                ? Image.memory(newCover!.bytes, fit: BoxFit.cover)
                : _ImageAny(_coverImageSourceFromItem(item));

            return Padding(
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 14,
                bottom: 16 + bottomInset,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Edit Item',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.of(sheetCtx).pop(),
                          icon: const Icon(Icons.close),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: SizedBox(
                        height: 160,
                        width: double.infinity,
                        child: coverWidget,
                      ),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: saving ? null : showEditCoverSource,
                      icon: const Icon(Icons.photo),
                      label: const Text(
                        'Change Cover',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: nameCtrl,
                      decoration: _inputDecoration(label: 'Item Name'),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: priceCtrl,
                      keyboardType: TextInputType.number,
                      inputFormatters: [ThousandsSeparatorInputFormatter()],
                      decoration: _inputDecoration(
                        label: 'Price (MWK)',
                        hint: 'e.g. 12,000',
                      ).copyWith(
                        suffixIcon: MerchantCommissionGuide.infoButton(
                          context,
                          priceText: priceCtrl.text,
                        ),
                      ),
                    ),
                    ValueListenableBuilder<TextEditingValue>(
                      valueListenable: priceCtrl,
                      builder: (context, value, _) =>
                          MerchantCommissionGuide.priceNote(
                        context,
                        priceText: value.text,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Quantity in stock *',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        IconButton.filledTonal(
                          onPressed: saving || stockQty <= 1
                              ? null
                              : () => setSheet(() {
                                    stockQty =
                                        (stockQty - 1).clamp(1, 99999);
                                    stockCtrl.text = '$stockQty';
                                  }),
                          icon: const Icon(Icons.remove_rounded),
                        ),
                        SizedBox(
                          width: 56,
                          child: TextField(
                            controller: stockCtrl,
                            enabled: !saving,
                            textAlign: TextAlign.center,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            decoration: const InputDecoration(
                              isDense: true,
                              border: InputBorder.none,
                            ),
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 18,
                            ),
                            onChanged: (v) {
                              final n = int.tryParse(v) ?? 1;
                              setSheet(
                                  () => stockQty = n.clamp(1, 99999));
                            },
                          ),
                        ),
                        IconButton.filledTonal(
                          onPressed: saving
                              ? null
                              : () => setSheet(() {
                                    stockQty =
                                        (stockQty + 1).clamp(1, 99999);
                                    stockCtrl.text = '$stockQty';
                                  }),
                          icon: const Icon(Icons.add_rounded),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: locationCtrl,
                      decoration: _inputDecoration(label: 'Location'),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: _kCategories.contains(category)
                          ? category
                          : 'other',
                      items: _kCategories
                          .map((c) => DropdownMenuItem(
                                value: c,
                                child:
                                    Text(c[0].toUpperCase() + c.substring(1)),
                              ))
                          .toList(),
                      onChanged: saving
                          ? null
                          : (v) => setSheet(() => category = v ?? 'other'),
                      decoration: _inputDecoration(label: 'Category'),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: descCtrl,
                      minLines: 3,
                      maxLines: 5,
                      decoration:
                          _inputDecoration(label: 'Description (optional)'),
                    ),
                    const SizedBox(height: 12),
                    if (_itemReviewStatus(item) == 'rejected') ...[
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFEBEE),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFFFCDD2)),
                        ),
                        child: Text(
                          (item['rejectedReason'] ??
                                  'This listing was not approved. Edit the photo/text and save to resubmit for review.')
                              .toString(),
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                            height: 1.35,
                            color: Color(0xFFB71C1C),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Tip: use a clear product photo on a plain background ? avoid people, selfies, or suggestive poses.',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                          height: 1.3,
                          color: Color(0xFF6B778C),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                    if (_itemReviewStatus(item) == 'pending') ...[
                      const Text(
                        'Under review G?? edits will keep this listing pending until approved.',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                    if (_itemReviewStatus(item) == 'approved')
                      Row(
                        children: [
                          Switch(
                            value: isActive,
                            onChanged: saving
                                ? null
                                : (v) => setSheet(() => isActive = v),
                          ),
                          Text(
                            isActive ? 'Live' : 'Inactive',
                            style:
                                const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ],
                      ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        style: _filledBtnStyle(),
                        onPressed: saving ? null : save,
                        icon: saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.save),
                        label: Text(
                          _itemReviewStatus(item) == 'rejected' ||
                                  _itemReviewStatus(item) == 'pending'
                              ? 'Post on Marketplace'
                              : 'Save Changes',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    // G?? allow sheet route to fully finish closing animation before disposing
    await Future.delayed(const Duration(milliseconds: 350));
    nameCtrl.dispose();
    priceCtrl.dispose();
    locationCtrl.dispose();
    descCtrl.dispose();
    stockCtrl.dispose();
    _sheetOpen = false;

    if (savedName != null && mounted) {
      await _loadItems(showLoading: false);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        final label = savedName.trim().isEmpty ? 'Item' : savedName.trim();
        _toastOk('Updated "$label"');
      });
    }
  }

  // ----------------- Location helpers -----------------
  Future<void> _getCurrentLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (!mounted) return;
        _toastErr('Location services are disabled.');
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (!mounted) return;
          _toastErr('Location permissions are denied.');
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (!mounted) return;
        _toastErr('Location permissions are permanently denied.');
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      final placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);

      if (placemarks.isEmpty) {
        if (!mounted) return;
        _toastErr('Could not fetch address.');
        return;
      }

      final place = placemarks[0];
      final address = [
        place.name,
        place.street,
        place.locality,
        place.administrativeArea,
        place.country,
      ].where((e) => e != null && e.isNotEmpty).join(', ');

      setState(() => _location.text = address);
    } catch (e) {
      debugPrint('Location error: $e');
      if (!mounted) return;
      _toastErr('Failed to get location. Please try again.');
    }
  }

  Future<void> _openGoogleMap() async {
    if (_location.text.trim().isEmpty) {
      _toastErr('Enter a location first.');
      return;
    }
    final query = Uri.encodeComponent(_location.text.trim());
    final uri =
        Uri.parse('https://www.google.com/maps/search/?api=1&query=$query');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      _toastErr('Could not open Google Maps.');
    }
  }

  Future<void> _rememberCommissionGuideIfAlreadyShown() async {
    if (_commissionGuideShownThisInstall) {
      _addItemCommissionShown = true;
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool(_commissionGuidePrefKey) == true) {
        _commissionGuideShownThisInstall = true;
        _addItemCommissionShown = true;
      }
    } catch (_) {}
  }

  void _onPriceFieldFocused() {
    if (!_priceFocus.hasFocus) return;
    _showAddItemCommissionGuide();
  }

  void _showAddItemCommissionGuide() {
    if (_addItemCommissionShown ||
        _commissionGuideShownThisInstall ||
        !mounted) {
      return;
    }
    _addItemCommissionShown = true;
    unawaited(_showCommissionGuideOnce());
  }

  Future<void> _showCommissionGuideOnce() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool(_commissionGuidePrefKey) == true) {
        _commissionGuideShownThisInstall = true;
        return;
      }
      await prefs.setBool(_commissionGuidePrefKey, true);
    } catch (_) {}
    _commissionGuideShownThisInstall = true;
    if (!mounted) return;
    await MerchantCommissionGuide.show(
      context,
      price: double.tryParse(_price.text.replaceAll(RegExp(r'[^0-9.]'), '')),
    );
  }

  // ----------------- UI helpers -----------------
  InputDecoration _inputDecoration({String? label, String? hint}) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      enabledBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: Colors.black12),
        borderRadius: BorderRadius.circular(14),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: _brandOrange, width: 2),
        borderRadius: BorderRadius.circular(14),
      ),
    );
  }

  ButtonStyle _filledBtnStyle({double padV = 14}) => FilledButton.styleFrom(
        backgroundColor: _brandOrange,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: EdgeInsets.symmetric(vertical: padV, horizontal: 14),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
      );

  Widget _compactStatTile({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: Colors.black54),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    value,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ----------------- NAV + Scaffold -----------------
  int _selectedIndex = 0;

  void _onItemTapped(int index) => setState(() => _selectedIndex = index);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F7),
      appBar: _selectedIndex == 4 ? _buildDashboardAppBar() : null,
      body: _getCurrentPage(),
      bottomNavigationBar: widget.embeddedInMainNav ? null : _buildMerchantNavBar(),
    );
  }

  AppBar _buildDashboardAppBar() {
    return AppBar(
      titleSpacing: 0,
      title: const Row(
        children: [
          Icon(
            Icons.storefront_rounded,
            color: Colors.white,
            size: 22,
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Merchant Dashboard',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
      backgroundColor: _brandOrange,
      actions: [
        const VeroCoinIconButton(
          size: 36,
          iconSize: 18,
          badgeBackground: Colors.white,
          badgeTextColor: Color(0xFFD94F00),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              StoryProfileRing(
                merchantId: _auth.currentUser?.uid ?? _uid,
                merchantName: _displayBusinessName(),
                merchantImageUrl:
                    _merchantProfileUrl.isNotEmpty ? _merchantProfileUrl : null,
                size: 36,
                imageProvider: _profileImageProvider(),
                placeholderIcon: Icons.person,
                onNoStoriesTap: () {
                  final uid = _auth.currentUser?.uid;
                  if (uid == null) {
                    _toastErr('Please sign in to post a story');
                    return;
                  }
                  Navigator.push(
                    context,
                    MaterialPageRoute<bool>(
                      builder: (_) => PostStoryPage(
                        merchantId: uid,
                        merchantName: _displayBusinessName(),
                        merchantImageUrl: _merchantProfileUrl.isNotEmpty
                            ? _merchantProfileUrl
                            : null,
                        serviceType: 'marketplace',
                      ),
                    ),
                  );
                },
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: () {
                    final uid = _auth.currentUser?.uid;
                    if (uid == null) {
                      _toastErr('Please sign in to post a story');
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute<bool>(
                        builder: (_) => PostStoryPage(
                          merchantId: uid,
                          merchantName: _displayBusinessName(),
                          merchantImageUrl: _merchantProfileUrl.isNotEmpty
                              ? _merchantProfileUrl
                              : null,
                          serviceType: 'marketplace',
                        ),
                      ),
                    );
                  },
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: Container(
                      margin: const EdgeInsets.all(2),
                      decoration: const BoxDecoration(
                        color: Color(0xFF25D366),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.add,
                        size: 14,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        IconButton(
          icon: const Icon(Icons.settings),
          tooltip: 'Settings',
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SettingsPage(onBackToHomeTab: () {}),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _getCurrentPage() {
    switch (_selectedIndex) {
      case 0:
        return Vero360Homepage(email: widget.email);
      case 1:
        return MarketPage(
          cartService: _cartService,
          onBackToHome: () => setState(() => _selectedIndex = 0),
        );
      case 2:
        return CartPage(cartService: _cartService);
      case 3:
        return const ChatListPage();
      case 4:
        return _buildDashboardContent();
      default:
        return Vero360Homepage(email: widget.email);
    }
  }

  String _merchantGuideDoneKey([String? uid]) {
    final id = (uid ?? _auth.currentUser?.uid ?? '').trim();
    if (id.isEmpty) return _kMerchantGuidePrefKey;
    return '${_kMerchantGuidePrefKey}_$id';
  }

  Future<bool> _isMerchantGuideDone(SharedPreferences prefs) async {
    final uid = (_auth.currentUser?.uid ?? '').trim();
    final scoped = _merchantGuideDoneKey(uid);
    if (prefs.getBool(scoped) == true) return true;
    // Migrate legacy device-wide flag ? per-account.
    if (prefs.getBool(_kMerchantGuidePrefKey) == true) {
      if (uid.isNotEmpty) {
        await prefs.setBool(scoped, true);
      }
      return true;
    }
    return false;
  }

  Future<void> _maybeShowMerchantGuide() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // Show guide until the merchant has completed or skipped it (once per account).
      if (await _isMerchantGuideDone(prefs)) return;
      if (!mounted) return;
      setState(() {
        _showMerchantGuide = true;
        _merchantGuideStep = 0;
      });
      // Match the first card (Add Item) to the Add Item tab G?? not the previous tab.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_showMerchantGuide) return;
        _syncMerchantGuideTab(_merchantGuideStep);
      });
    } catch (_) {}
  }

  /// Tabs: 0 Dashboard, 1 Add Item, 2 My Items, 3 Profile.
  void _syncMerchantGuideTab(int step) {
    if (step < 0 || step >= _merchantGuideSteps.length) return;
    final int tab = switch (step) {
      0 => 1, // Add Item
      1 => 2, // My Items
      2 || 3 => 0, // Wallet + orders / recent sales on Dashboard
      _ => 0,
    };
    if (_marketplaceTabs.index == tab) return;
    _marketplaceTabs.animateTo(tab);
  }

  Future<void> _completeMerchantGuide() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final uid = (_auth.currentUser?.uid ?? '').trim();
      await prefs.setBool(_merchantGuideDoneKey(uid), true);
      // Legacy key kept so older login checks still treat the guide as finished.
      await prefs.setBool(_kMerchantGuidePrefKey, true);
      await prefs.setBool(_kMerchantGuideShowOnNextOpenKey, false);
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _showMerchantGuide = false;
      _merchantGuideStep = 0;
    });
  }

  static const List<({String title, String body, IconData icon})> _merchantGuideSteps = [
    (title: 'ikani katundu wanu koyamba', body: 'Dinani "Add Item" kuti muike katundu wanu. kenako ikani  name, price, photo and category.', icon: Icons.add_box_rounded),
    (title: 'kulongosola katundu wanu', body: 'Yuzani "My Items"  kt mu wone, musithe,kuika ndikuchosa katundu wanu pa msika.', icon: Icons.inventory_2_rounded),
    (title: 'Tsegulani waleti yanu', body: 'tsegulani Waleti yanu pa dashboard kuti muthe kulandila ma payments and ikani PIN kuti muteteze waleti yanu.', icon: Icons.account_balance_wallet_rounded),
    (title: 'Mukagulisa', body: 'pitani ku dashboard dinani send parcels,ikani receipt ya courier tumizani katundu kenako dikililani ndalama zanu . onani zomwe mwagulisa pa recent Sales  ndipo pangani makasitomala anu kukhala a tcheru.', icon: Icons.local_shipping_rounded),
  ];

  Widget _buildMerchantGuideOverlay() {
    final step = _merchantGuideSteps[_merchantGuideStep];
    final isLast = _merchantGuideStep == _merchantGuideSteps.length - 1;

    return Material(
      color: Colors.black54,
      child: SafeArea(
        child: Stack(
          children: [
            GestureDetector(onTap: () {}),
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.15),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Quick guide',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: _brandOrange,
                            ),
                          ),
                          TextButton(
                            onPressed: () => _completeMerchantGuide(),
                            style: TextButton.styleFrom(foregroundColor: _brandOrange),
                            child: const Text('Skip'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _brandOrange.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(step.icon, size: 48, color: _brandOrange),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        step.title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        step.body,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade700,
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          _merchantGuideSteps.length,
                          (i) => Container(
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            width: i == _merchantGuideStep ? 20 : 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: i == _merchantGuideStep
                                  ? _brandOrange
                                  : Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          style: FilledButton.styleFrom(
                            backgroundColor: _brandOrange,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          onPressed: () {
                            if (isLast) {
                              _completeMerchantGuide();
                              return;
                            }
                            setState(() => _merchantGuideStep++);
                            WidgetsBinding.instance.addPostFrameCallback((_) {
                              if (!mounted) return;
                              _syncMerchantGuideTab(_merchantGuideStep);
                            });
                          },
                          child: Text(
                            isLast ? 'Ndamva!' : 'Next',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardContent() {
    if (_isLoading) {
      return const _DashboardSkeleton();
    }

    if (!_merchantGuideCheckScheduled) {
      _merchantGuideCheckScheduled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowMerchantGuide());
    }

    // G?? removed DefaultTabController (it can trigger dependents assertion in some setups)
    return Stack(
      children: [
        Column(
          children: [
            Container(
              color: Colors.white,
              child: TabBar(
                controller: _marketplaceTabs,
                isScrollable: true,
                tabAlignment: TabAlignment.start,
                labelPadding: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                labelColor: _brandOrange,
                unselectedLabelColor: Colors.grey,
                indicatorColor: _brandOrange,
                labelStyle: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                ),
                unselectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
                tabs: const [
                  Tab(text: 'Dashboard'),
                  Tab(text: 'Add Item'),
                  Tab(text: 'My Items'),
                  Tab(text: 'Profile'),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _marketplaceTabs,
                children: [
                  RefreshIndicator(
                    onRefresh: _refreshAll,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(
                        16,
                        16,
                        16,
                        veroFloatingNavClearance(context),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildModernHeaderCard(),
                          const SizedBox(height: 12),
                          _buildKycSection(),
                          const SizedBox(height: 12),
                          _buildStatsSection(),
                          const SizedBox(height: 12),
                          _buildQuickActionsSection(),
                          const SizedBox(height: 12),
                          _buildWalletSummary(),
                          const SizedBox(height: 12),
                          _buildRecentSales(),
                          const SizedBox(height: 12),
                          _buildAllClientItemsSection(),
                        ],
                      ),
                    ),
                  ),
                  _buildAddItemTab(),
                  _buildMyItemsTab(),
                  _buildProfileTab(),
                ],
              ),
            ),
          ],
        ),
        if (_showMerchantGuide) _buildMerchantGuideOverlay(),
      ],
    );
  }

  // ----------------- Profile tab (after My Items) -----------------
  Widget _buildProfileTab() {
    return RefreshIndicator(
      color: _brandOrange,
      onRefresh: _refreshAll,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.fromLTRB(
          16,
          16,
          16,
          veroFloatingNavClearance(context),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildModernHeaderCard(),
            const SizedBox(height: 12),
            _buildKycSection(),
            const SizedBox(height: 12),
            const Text(
              'Shop profile',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 4),
            Text(
              'Edit what customers see on your marketplace shop.',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 12.5,
              ),
            ),
            const SizedBox(height: 10),
            _profileEditTile(
              icon: Icons.storefront_rounded,
              title: 'Business name',
              subtitle: _displayBusinessName(),
              onTap: _editBusinessName,
            ),
            const SizedBox(height: 10),
            _profileEditTile(
              icon: Icons.schedule_rounded,
              title: 'Business hours',
              subtitle: _shopHoursSummary,
              onTap: _editShopHours,
            ),
            const SizedBox(height: 10),
            _profileEditTile(
              icon: Icons.phone_rounded,
              title: 'Phone number',
              subtitle: _displayMerchantPhone,
              onTap: _editPhone,
            ),
            const SizedBox(height: 10),
            _profileEditTile(
              icon: Icons.location_on_rounded,
              title: 'Shop location',
              subtitle: _businessLocation.trim().isEmpty
                  ? 'Type, search, or pin your storefront'
                  : _businessLocation.trim(),
              onTap: _editBusinessLocation,
            ),
            const SizedBox(height: 10),
            _profileEditTile(
              icon: Icons.notes_rounded,
              title: 'Business description',
              subtitle: _businessDescription.trim().isEmpty
                  ? 'Tell customers about your shop'
                  : _businessDescription.trim(),
              onTap: _editBusinessDescription,
            ),
            const SizedBox(height: 10),
            _profileEditTile(
              icon: Icons.settings_rounded,
              title: 'Account settings',
              subtitle: 'Security, notifications, and more',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => SettingsPage(onBackToHomeTab: () {}),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _profileEditTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: (_profileBusy || _profileUploading) ? null : onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(14, 14, 12, 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.black12),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _brandOrange.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: _brandOrange),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.grey.shade700,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.chevron_right_rounded,
                color: Colors.grey.shade400,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ----------------- Header (modern) -----------------
  Widget _buildKycSection() {
    final status = _kycStatus.trim().toLowerCase();
    final verified = status == 'verified' || status == 'approved';
    final pending = status == 'pending' ||
        status == 'in_review' ||
        status == 'submitted' ||
        status == 'in_progress' ||
        status == 'pending_review' ||
        status == 'resubmitted';
    final rejected = status == 'rejected' || status == 'declined';

    late final String title;
    late final String subtitle;
    late final String badgeLabel;
    late final IconData icon;
    late final List<Color> markGradient;
    late final Color badgeBg;
    late final Color badgeFg;
    late final Color badgeBorder;
    late final Color accent;
    late final Color cardWash;

    if (verified) {
      title = 'Identity verified';
      subtitle = 'Your KYC check is complete.';
      badgeLabel = 'Verified';
      icon = Icons.verified_user_rounded;
      markGradient = const [Color(0xFF34C759), Color(0xFF1B8F3E)];
      badgeBg = const Color(0xFFEAF8EF);
      badgeFg = const Color(0xFF1B8F3E);
      badgeBorder = const Color(0xFFB7E6C5);
      accent = const Color(0xFF1B8F3E);
      cardWash = const Color(0xFFF4FBF6);
    } else if (pending) {
      title = 'Verification in progress';
      subtitle = 'We are reviewing your Didit submission.';
      badgeLabel = 'In review';
      icon = Icons.hourglass_top_rounded;
      markGradient = const [Color(0xFFFFB347), Color(0xFFE86F00)];
      badgeBg = const Color(0xFFFFF3E6);
      badgeFg = const Color(0xFFB86E00);
      badgeBorder = const Color(0xFFFFD9A8);
      accent = const Color(0xFFE86F00);
      cardWash = const Color(0xFFFFFBF7);
    } else if (rejected) {
      title = 'Verification needs attention';
      subtitle = _kycRejectionReason.isNotEmpty
          ? _kycRejectionReason
          : 'Your previous attempt was declined. Try again.';
      badgeLabel = 'Action needed';
      icon = Icons.gpp_bad_rounded;
      markGradient = const [Color(0xFFFF6B6B), Color(0xFFD14343)];
      badgeBg = const Color(0xFFFFF1F0);
      badgeFg = const Color(0xFFD14343);
      badgeBorder = const Color(0xFFFFD4D0);
      accent = const Color(0xFFD14343);
      cardWash = const Color(0xFFFFF8F7);
    } else {
      title = 'Verify your identity';
      subtitle =
          'Quick ID + face check with Didit ? unlock full merchant trust.';
      badgeLabel = 'Required';
      icon = Icons.badge_outlined;
      markGradient = const [Color(0xFFFF9A1F), Color(0xFFE86F00)];
      badgeBg = const Color(0xFFFFF3E6);
      badgeFg = const Color(0xFFE86F00);
      badgeBorder = const Color(0xFFFFD9A8);
      accent = _brandOrange;
      cardWash = const Color(0xFFFFFBF7);
    }

    final canStart = !verified;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: canStart ? _openKycVerification : null,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                cardWash,
                Colors.white,
              ],
            ),
            border: Border.all(
              color: accent.withValues(alpha: 0.18),
            ),
            boxShadow: [
              BoxShadow(
                color: accent.withValues(alpha: 0.08),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 12, 14),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: markGradient,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: markGradient.last.withValues(alpha: 0.28),
                        blurRadius: 12,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Icon(icon, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'KYC verification',
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                                letterSpacing: -0.2,
                                color: Color(0xFF141414),
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 7,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: badgeBg,
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: badgeBorder, width: 0.8),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 5,
                                  height: 5,
                                  decoration: BoxDecoration(
                                    color: badgeFg,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  badgeLabel,
                                  style: TextStyle(
                                    color: badgeFg,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 10,
                                    height: 1.1,
                                    letterSpacing: 0.05,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        title,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 13.5,
                          letterSpacing: -0.15,
                          color: accent,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: Color(0xFF6B6B6B),
                          fontSize: 12.5,
                          height: 1.35,
                          fontWeight: FontWeight.w400,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                if (canStart) ...[
                  const SizedBox(width: 4),
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.arrow_forward_rounded,
                      size: 16,
                      color: accent,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModernHeaderCard() {
    final business = _displayBusinessName();
    final st = _status.trim().toLowerCase();
    final statusText = st.isEmpty ? 'PENDING' : st.toUpperCase();

    Color statusBg;
    Color statusFg;
    if (st == 'approved' || st == 'active') {
      statusBg = const Color(0xFFE7F6EC);
      statusFg = Colors.green.shade700;
    } else if (st == 'pending' || st == 'under_review' || st == 'submitted') {
      statusBg = const Color(0xFFFFF3E5);
      statusFg = const Color(0xFFB86E00);
    } else {
      statusBg = const Color(0xFFFFEDEE);
      statusFg = Colors.red.shade700;
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(
          colors: [_brandNavy, _brandNavy.withOpacity(0.86)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 10),
          )
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                StoryProfileRing(
                  merchantId: _uid.isNotEmpty ? _uid : (_auth.currentUser?.uid ?? ''),
                  merchantName: business,
                  merchantImageUrl:
                      _merchantProfileUrl.isNotEmpty ? _merchantProfileUrl : null,
                  size: 56,
                  imageProvider: _profileImageProvider(),
                  placeholderIcon: Icons.storefront_rounded,
                  onNoStoriesTap: _viewProfilePhoto,
                ),
                  Positioned(
                    bottom: -2,
                    right: -2,
                    child: GestureDetector(
                      onTap: _showPhotoSheet,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: _brandOrange,
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: _profileUploading
                            ? const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.edit,
                                size: 14, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    business,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _merchantEmail,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontWeight: FontWeight.w600),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _displayMerchantPhone,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontWeight: FontWeight.w600),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  if (_businessDescription.trim().isNotEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _businessDescription.trim(),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.92),
                          fontWeight: FontWeight.w600,
                          fontSize: 12.5,
                          height: 1.35,
                        ),
                      ),
                    ),
                  if (_businessDescription.trim().isNotEmpty)
                    const SizedBox(height: 6),
                  if (_openTime != null && _closeTime != null)
                    Row(
                      children: [
                        const Icon(
                          Icons.schedule_rounded,
                          size: 14,
                          color: Colors.white70,
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            _shopHoursSummary,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.9),
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  if (_openTime != null && _closeTime != null)
                    const SizedBox(height: 10)
                  else
                    const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                            color: statusBg,
                            borderRadius: BorderRadius.circular(999)),
                        child: Text(statusText,
                            style: TextStyle(
                                color: statusFg,
                                fontWeight: FontWeight.w900,
                                fontSize: 12)),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                            color: Colors.amber.shade100,
                            borderRadius: BorderRadius.circular(999)),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.star, size: 14),
                            Text(' ${_rating.toStringAsFixed(1)}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900, fontSize: 12)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _isShopOpenNow
                              ? const Color(0xFFE7F6EC)
                              : const Color(0xFFFFEDEE),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          _isShopOpenNow ? 'We are open' : 'We are closed',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 12,
                            color: _isShopOpenNow
                                ? Colors.green.shade700
                                : Colors.red.shade700,
                          ),
                        ),
                      ),
                      if (_loadingMe)
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ----------------- Smaller Business Overview cards -----------------
  Widget _buildStatsSection() {
    // Use fixed Rows (not nested GridView) so TabBarView/scroll nesting
    // cannot invent a full-viewport empty gap under the tiles.
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Business Overview',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        _twoColumnTiles(
          height: 74,
          children: [
            _compactStatTile(
              title: 'Total Items',
              value: '$_totalItems',
              icon: Icons.inventory_2,
              color: _brandOrange,
            ),
            _compactStatTile(
              title: 'Active Items',
              value: '$_activeItems',
              icon: Icons.verified_rounded,
              color: Colors.green,
            ),
            _compactStatTile(
              title: 'Sold Items',
              value: '$_soldItems',
              icon: Icons.shopping_bag_rounded,
              color: Colors.blue,
            ),
            _compactStatTile(
              title: 'Earnings',
              value: mwk0(_totalEarnings),
              icon: Icons.payments_rounded,
              color: Colors.green,
            ),
          ],
        ),
      ],
    );
  }

  /// Compact 2-column tile grid without nested scrollables.
  Widget _twoColumnTiles({
    required List<Widget> children,
    double height = 74,
    double gap = 12,
  }) {
    final rows = <Widget>[];
    for (var i = 0; i < children.length; i += 2) {
      if (i > 0) rows.add(SizedBox(height: gap));
      final right = i + 1 < children.length ? children[i + 1] : null;
      rows.add(
        SizedBox(
          height: height,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(child: children[i]),
              SizedBox(width: gap),
              Expanded(child: right ?? const SizedBox.shrink()),
            ],
          ),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: rows,
    );
  }

  // ----------------- Quick actions + profile actions -----------------
  Widget _buildQuickActionsSection() {
    final actions = <Widget>[
      _QuickActionTile(
        title: 'Add Item',
        icon: Icons.add_circle_outline,
        color: _brandOrange,
        onTap: () => _marketplaceTabs.animateTo(1),
      ),
      _QuickActionTile(
        title: 'My Items',
        icon: Icons.inventory_2_outlined,
        color: _brandNavy,
        onTap: () => _marketplaceTabs.animateTo(2),
      ),
      _QuickActionTile(
        title: 'My Orders',
        icon: Icons.receipt_long,
        color: Colors.green,
        badgeRoute: NotificationStore.kBadgeMyOrders,
        onTap: () => _openBottomSheet(const OrdersPage()),
      ),
      _QuickActionTile(
        title: 'Latest Arrivals',
        icon: Icons.rocket,
        color: Colors.orange,
        badgeRoute: NotificationStore.kBadgePostArrival,
        onTap: () => _openBottomSheet(const LatestArrivalsCrudPage()),
      ),
      _QuickActionTile(
        title: 'Send parcels',
        icon: Icons.local_shipping_outlined,
        color: Colors.orange,
        badgeRoute: NotificationStore.kBadgeShipped,
        onTap: () => _openBottomSheet(const ToShipPage()),
      ),
      _QuickActionTile(
        title: 'Received',
        icon: Icons.move_to_inbox_outlined,
        color: Colors.blue,
        badgeRoute: NotificationStore.kBadgeReceived,
        onTap: () => _openBottomSheet(const DeliveredOrdersPage()),
      ),
      _QuickActionTile(
        title: 'Refund',
        icon: Icons.replay_circle_filled_outlined,
        color: Colors.red,
        badgeRoute: NotificationStore.kBadgeRefund,
        onTap: () => _openBottomSheet(const ToRefundPage()),
      ),
      _QuickActionTile(
        title: 'Promotions',
        icon: Icons.campaign_outlined,
        color: Colors.orange,
        badgeRoute: NotificationStore.kBadgePromotions,
        onTap: () => _openBottomSheet(const PromotionsCrudPage()),
      ),
      _QuickActionTile(
        title: 'Shop pictures',
        icon: Icons.photo_library_outlined,
        color: Colors.teal,
        onTap: _openShopPictures,
      ),
      _QuickActionTile(
        title: 'My Vero Ride',
        icon: Icons.directions_car_filled_rounded,
        color: Colors.orange,
        onTap: _openRideHistory,
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Quick Actions',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        _twoColumnTiles(height: 74, children: actions),
      ],
    );
  }

  void _openRideHistory() {
    _openBottomSheet(
      const RideHistoryScreen(mode: RideHistoryMode.passenger),
    );
  }

  void _openShopPictures() {
    final uid = _uid.trim().isEmpty
        ? (FirebaseAuth.instance.currentUser?.uid ?? '')
        : _uid.trim();
    if (uid.isEmpty) return;
    _openBottomSheet(
      ShopPicturesPage(
        merchantIds: [uid],
        shopName: _displayBusinessName(),
        canManage: true,
      ),
    );
  }

  void _openBottomSheet(Widget child) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.88,
        child: child,
      ),
    );
  }

  // ----------------- Wallet Summary (LOCKED) -----------------
  Widget _buildWalletSummary() {
    final titleName = _displayBusinessName();
    final unlocked = _walletUnlockedNow;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: (unlocked ? Colors.green : Colors.grey).withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              unlocked
                  ? Icons.account_balance_wallet_rounded
                  : Icons.lock_rounded,
              color: unlocked ? Colors.green : Colors.grey,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Wallet Balance',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(
                  unlocked ? mwk2(_walletBalance) : 'MWK G??G??G??G??', // G?? commas
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: unlocked ? Colors.green : Colors.black54,
                  ),
                ),
                if (!unlocked)
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text(
                      'Locked G?? tap Open to unlock',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: Colors.black54,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: _brandOrange,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: () async {
              final ok = await _unlockWalletWithPin();
              if (!ok || !mounted) return;

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MerchantWalletPage(
                    merchantId: _uid,
                    merchantName: titleName,
                    serviceType: 'marketplace',
                  ),
                ),
              );
            },
            child: const Text('Open',
                style: TextStyle(fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }

  // ----------------- Recent Sales (real confirmed+paid orders) -----------------
  static final DateFormat _recentSaleDateFmt =
      DateFormat('dd MMM yyyy, HH:mm');

  Widget _buildRecentSales() {
    final query = _recentSalesSearchController.text.trim().toLowerCase();
    final filtered = query.isEmpty
        ? _recentSalesOrders
        : _recentSalesOrders.where((o) {
            return o.orderNumber.toLowerCase().contains(query) ||
                o.itemName.toLowerCase().contains(query);
          }).toList();
    final displayList = filtered.take(20).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('Recent Sales',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            ),
            IconButton(
              icon: const Icon(Icons.search_rounded),
              onPressed: () => _recentSalesSearchFocus.requestFocus(),
              tooltip: 'Search by order number or item name',
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: TextField(
            controller: _recentSalesSearchController,
            focusNode: _recentSalesSearchFocus,
            decoration: InputDecoration(
              hintText: 'Order No or item name',
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              suffixIcon: query.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear_rounded, size: 20),
                      onPressed: () {
                        _recentSalesSearchController.clear();
                        setState(() {});
                      },
                    )
                  : null,
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              filled: true,
              fillColor: Colors.grey.shade50,
            ),
            onChanged: (_) => setState(() {}),
          ),
        ),
        const SizedBox(height: 6),
        if (_recentSalesOrders.isEmpty)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.black12),
            ),
            child: const Center(child: Text('No sales yet')),
          )
        else if (displayList.isEmpty)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.black12),
            ),
            child: Center(
                child: Text('No matches for "$query"')),
          )
        else
          ...displayList.map((o) {
            final dateStr = o.orderDate != null
                ? _recentSaleDateFmt.format(o.orderDate!.toLocal())
                : 'G??';
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black12),
              ),
              child: ListTile(
                leading: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: _brandOrange.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.shopping_bag_rounded,
                      color: _brandOrange),
                ),
                title: Text(o.itemName,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Order: ${o.orderNumber}'),
                          IconButton(
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                            icon: const Icon(Icons.copy_rounded, size: 18),
                            onPressed: () {
                              Clipboard.setData(ClipboardData(text: o.orderNumber));
                              ToastHelper.showCustomToast(context, 'Order number copied', isSuccess: true, errorMessage: '');
                            },
                            tooltip: 'Copy order number',
                          ),
                        ],
                      ),
                      Text('${mwk0(o.total)}  -+  $dateStr'),
                    ],
                  ),
                ),
                trailing: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: const Text('Paid',
                      style: TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ),
            );
          }),
      ],
    );
  }


  // ----------------- "My Items" on Dashboard — with promote -----------------
  Widget _buildAllClientItemsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'My Items',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
              ),
            ),
            TextButton.icon(
              onPressed: () => _marketplaceTabs.animateTo(2),
              icon: const Icon(Icons.campaign_rounded, size: 18),
              label: const Text(
                'Promote',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              style: TextButton.styleFrom(
                foregroundColor: _brandOrange,
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          'Tap the megaphone on a live item to boost it.',
          style: TextStyle(
            color: Colors.grey.shade700,
            fontWeight: FontWeight.w600,
            fontSize: 12.5,
          ),
        ),
        const SizedBox(height: 10),
        if (_loadingItems)
          const _ItemsGridSkeleton(count: 6)
        else if (_items.isEmpty)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.black12),
            ),
            child: const Center(child: Text('No items yet')),
          )
        else ...[
          // shrinkWrap builds every card up front; keep the preview small.
          GridView.builder(
            shrinkWrap: true,
            primary: false,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _items.length.clamp(0, _kHomeItemsPreview),
            gridDelegate: _merchantItemsGridDelegate(context),
            itemBuilder: (_, i) {
              final it = _items[i];
              return _ModernItemMiniCard(
                item: it,
                busy: _busyRow,
                onPromote: () => _promoteItem(it),
              );
            },
          ),
          if (_items.length > _kHomeItemsPreview)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _marketplaceTabs.animateTo(2),
                  icon: const Icon(Icons.grid_view_rounded, size: 18),
                  label: Text(
                    'See all ${_items.length} items',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _brandOrange,
                    side: BorderSide(color: _brandOrange.withValues(alpha: 0.5)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ],
    );
  }

  static const int _kHomeItemsPreview = 6;

  Future<void> _promoteItem(Map<String, dynamic> it) async {
    final id = (it['id'] ?? '').toString().trim();
    if (id.isEmpty) return;
    final canPromote =
        _itemReviewStatus(it) == 'approved' &&
        it['isActive'] == true &&
        !_itemIsSold(it);
    if (!canPromote) {
      ToastHelper.showCustomToast(
        context,
        'Only live (approved) items can be promoted.',
        isSuccess: false,
        errorMessage: 'Cannot promote',
      );
      return;
    }
    await MarketplacePromoteService.presentPromoteSheet(
      context: context,
      itemId: id,
      item: it,
    );
    await _loadItems(showLoading: false);
  }

  // ----------------- G?? Add Item Tab (with multi-photos) -----------------
  Widget _buildAddItemTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
        16,
        16,
        16,
        veroFloatingNavClearance(context),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: AbsorbPointer(
            absorbing: _submitting,
            child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Add New Item',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              const Text('Cover Image',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: _cover == null
                    ? Container(
                        height: 160,
                        color: const Color(0xFFF3F4F7),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.image,
                                  size: 40, color: Colors.black26),
                              const SizedBox(height: 8),
                              FilledButton.icon(
                                style: FilledButton.styleFrom(
                                    backgroundColor: _brandOrange),
                                onPressed: _showCoverImageSource,
                                icon: const Icon(Icons.add_photo_alternate),
                                label: const Text('Select Image'),
                              ),
                            ],
                          ),
                        ),
                      )
                    : Stack(
                        children: [
                          Image.memory(
                            _cover!.bytes,
                            height: 160,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                          Positioned(
                            top: 8,
                            right: 8,
                            child: InkWell(
                              onTap: () => setState(() => _cover = null),
                              child: const CircleAvatar(
                                radius: 16,
                                backgroundColor: Colors.black54,
                                child: Icon(Icons.close,
                                    color: Colors.white, size: 16),
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
              const SizedBox(height: 14),

              // G?? More Photos
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'More Photos (optional)',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                  Text(
                    '${_gallery.length}/$_maxGalleryPhotos',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, color: Colors.black54),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _gallery.length >= _maxGalleryPhotos
                          ? null
                          : _showMorePhotosSource,
                      icon: const Icon(Icons.collections_outlined),
                      label: Text(
                        _gallery.isEmpty ? 'Add Photos' : 'Add More',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  if (_gallery.isNotEmpty)
                    OutlinedButton(
                      onPressed: () => setState(() => _gallery.clear()),
                      child: const Text('Clear',
                          style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              if (_gallery.isNotEmpty)
                SizedBox(
                  height: 96,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _gallery.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, i) {
                      final m = _gallery[i];
                      return SizedBox(
                        width: 96,
                        height: 96,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.memory(
                                m.bytes,
                                fit: BoxFit.cover,
                                gaplessPlayback: true,
                              ),
                            ),
                            Positioned(
                              top: 4,
                              right: 4,
                              child: InkWell(
                                onTap: () => _removeGalleryAt(i),
                                child: const CircleAvatar(
                                  radius: 12,
                                  backgroundColor: Colors.black54,
                                  child: Icon(Icons.close,
                                      size: 14, color: Colors.white),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),

              const SizedBox(height: 14),

              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Videos (optional)',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                  Text(
                    '${_videos.length}/$_maxVideos',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _videos.length >= _maxVideos
                      ? null
                      : _showVideoSource,
                  icon: const Icon(Icons.videocam_outlined),
                  label: Text(
                    _videos.isEmpty ? 'Add a video' : 'Add another video',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              if (_videos.isNotEmpty) ...[
                const SizedBox(height: 10),
                SizedBox(
                  height: 96,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _videos.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, i) {
                      return SizedBox(
                        width: 96,
                        height: 96,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: const ColoredBox(
                                color: Colors.black,
                                child: Icon(
                                  Icons.play_arrow_rounded,
                                  color: Colors.white,
                                  size: 36,
                                ),
                              ),
                            ),
                            Positioned(
                              top: 4,
                              right: 4,
                              child: InkWell(
                                onTap: () => setState(() => _videos.removeAt(i)),
                                child: const CircleAvatar(
                                  radius: 12,
                                  backgroundColor: Colors.black54,
                                  child: Icon(
                                    Icons.close,
                                    size: 14,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],

              const SizedBox(height: 14),

              TextField(
                  controller: _name,
                  decoration: _inputDecoration(label: 'Item Name')),
              const SizedBox(height: 10),
              TextField(
                  controller: _price,
                  focusNode: _priceFocus,
                  keyboardType: TextInputType.number,
                  inputFormatters: [ThousandsSeparatorInputFormatter()],
                  decoration: _inputDecoration(
                    label: 'Price (MWK)',
                    hint: 'e.g. 12,000',
                  ).copyWith(
                    suffixIcon: MerchantCommissionGuide.infoButton(
                      context,
                      priceText: _price.text,
                    ),
                  )),
              ValueListenableBuilder<TextEditingValue>(
                valueListenable: _price,
                builder: (context, value, _) => MerchantCommissionGuide.priceNote(
                  context,
                  priceText: value.text,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Quantity in stock *',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: _stockQty <= 1
                        ? null
                        : () => setState(() {
                              _stockQty = (_stockQty - 1).clamp(1, 99999);
                              _stock.text = '$_stockQty';
                            }),
                    icon: const Icon(Icons.remove_rounded),
                  ),
                  SizedBox(
                    width: 56,
                    child: TextField(
                      controller: _stock,
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly
                      ],
                      decoration: const InputDecoration(
                        isDense: true,
                        border: InputBorder.none,
                      ),
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                      onChanged: (v) {
                        final n = int.tryParse(v) ?? 1;
                        setState(() => _stockQty = n.clamp(1, 99999));
                      },
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: () => setState(() {
                      _stockQty = (_stockQty + 1).clamp(1, 99999);
                      _stock.text = '$_stockQty';
                    }),
                    icon: const Icon(Icons.add_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _location,
                decoration: _inputDecoration(label: 'Location').copyWith(
                  suffixIcon: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                          icon: const Icon(Icons.my_location),
                          onPressed: _getCurrentLocation),
                      IconButton(
                          icon: const Icon(Icons.map),
                          onPressed: _openGoogleMap),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _kCategories.contains(_category) ? _category : 'other',
                items: _kCategories
                    .map((c) => DropdownMenuItem(
                          value: c,
                          child: Text(c[0].toUpperCase() + c.substring(1)),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _category = v),
                decoration: _inputDecoration(label: 'Category'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _desc,
                minLines: 3,
                maxLines: 5,
                decoration: _inputDecoration(label: 'Description (optional)'),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF4E5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFFFD59A)),
                ),
                child: const Text(
                  'New listings are reviewed automatically before going live. '
                  'YouG??ll get a notification when yours is approved.',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    height: 1.35,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: _postToFacebook,
                activeThumbColor: _brandOrange,
                secondary: const FacebookLogoMark(size: 22),
                title: const Text(
                  'Also post on Facebook',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                subtitle: Text(
                  'Share on the Vero360 Facebook Page once approved.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade700,
                  ),
                ),
                onChanged: _submitting
                    ? null
                    : (v) => setState(() => _postToFacebook = v),
              ),
              if (_postToFacebook) ...[
                const SizedBox(height: 8),
                const FacebookShareHint(
                  message:
                      'Once approved, this listing is also shared on the Vero360 Facebook Page to help more buyers find you.',
                ),
              ],
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: _filledBtnStyle(),
                  onPressed: _submitting ? null : _create,
                  icon: _submitting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.upload_rounded),
                  label: Text(
                    _submitting
                        ? 'Posting…'
                        : (_postToFacebook
                            ? 'Post on Marketplace + Facebook'
                            : 'Post on Marketplace'),
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
            ),
          ),
        ),
      ),
    );
  }

  // ----------------- My Items Tab: Search + Filter chips + Edit -----------------
  Widget _buildMyItemsTab() {
    final filtered = _filteredItems();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
          child: Column(
            children: [
              TextField(
                onChanged: (v) => setState(() => _searchQuery = v),
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: 'Search items...',
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.black12),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: _brandOrange, width: 2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _chip(
                      label: 'All Categories',
                      selected: _filterCategory == 'all',
                      onTap: () => setState(() => _filterCategory = 'all'),
                    ),
                    ..._kCategories.map((c) => _chip(
                          label: c[0].toUpperCase() + c.substring(1),
                          selected: _filterCategory == c,
                          onTap: () => setState(() => _filterCategory = c),
                        )),
                    const SizedBox(width: 10),
                    _chip(
                      label: 'All',
                      selected: _filterStatus == 'all',
                      onTap: () => setState(() => _filterStatus = 'all'),
                    ),
                    _chip(
                      label: 'Live',
                      selected: _filterStatus == 'active',
                      onTap: () => setState(() => _filterStatus = 'active'),
                    ),
                    _chip(
                      label: 'Sold',
                      selected: _filterStatus == 'sold',
                      onTap: () => setState(() => _filterStatus = 'sold'),
                    ),
                    _chip(
                      label: 'Under review',
                      selected: _filterStatus == 'pending',
                      onTap: () => setState(() => _filterStatus = 'pending'),
                    ),
                    _chip(
                      label: 'Rejected',
                      selected: _filterStatus == 'rejected',
                      onTap: () => setState(() => _filterStatus = 'rejected'),
                    ),
                    _chip(
                      label: 'Inactive',
                      selected: _filterStatus == 'inactive',
                      onTap: () => setState(() => _filterStatus = 'inactive'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _loadingItems
              ? const _ItemsGridSkeleton(count: 8)
              : filtered.isEmpty
                  ? const Center(child: Text('No items match your filters'))
                  : GridView.builder(
                      padding: EdgeInsets.fromLTRB(
                        16,
                        0,
                        16,
                        veroFloatingNavClearance(context),
                      ),
                      itemCount: filtered.length,
                      gridDelegate: _merchantItemsGridDelegate(context),
                      itemBuilder: (_, i) => _ItemCard(
                        item: filtered[i],
                        busy: _busyRow,
                        onDelete: () => _deleteItem(filtered[i]),
                        onEdit: () => _openEditItemSheet(filtered[i]),
                        onPromote: () async {
                          await _promoteItem(filtered[i]);
                        },
                      ),
                    ),
        ),
      ],
    );
  }

  Widget _chip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: _brandOrange.withOpacity(0.16),
        labelStyle: TextStyle(color: selected ? _brandOrange : Colors.black87),
        side: const BorderSide(color: Colors.black12),
      ),
    );
  }

  // ----------------- cover picker -----------------
  void _showCoverImageSource() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);
                _pickCover(ImageSource.camera);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: Color(0xFFFF8A00),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.photo_camera_outlined,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Take a photo',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF222222),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.pop(context);
                _pickCover(ImageSource.gallery);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: Color(0xFF1E88E5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.photo_library_outlined,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Choose from gallery',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF222222),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickCover(ImageSource src) async {
    final x = await _picker.pickImage(
      source: src,
      imageQuality: 80,
      maxWidth: 1600,
    );
    if (x == null) return;
    final bytes = await x.readAsBytes();
    setState(() {
      _cover = LocalMedia(
        bytes: bytes,
        filename: x.name,
        mime: lookupMimeType(x.name, headerBytes: bytes),
      );
    });
  }

  void _showMorePhotosSource() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);
                _pickMorePhotosFromCamera();
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: Color(0xFFFF8A00),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.photo_camera_outlined,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Take a photo',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF222222),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.pop(context);
                _pickMorePhotos();
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          color: Color(0xFF1E88E5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.photo_library_outlined,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Choose from gallery',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF222222),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showVideoSource() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _mediaSourceRow(
                color: const Color(0xFFFF8A00),
                icon: Icons.videocam_outlined,
                label: 'Record a video',
                onTap: () {
                  Navigator.pop(context);
                  _pickListingVideo(ImageSource.camera);
                },
              ),
              _mediaSourceRow(
                color: const Color(0xFF111111),
                icon: Icons.video_library_outlined,
                label: 'Choose from gallery',
                onTap: () {
                  Navigator.pop(context);
                  _pickListingVideo(ImageSource.gallery);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mediaSourceRow({
    required Color color,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF222222),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickListingVideo(ImageSource source) async {
    try {
      if (_videos.length >= _maxVideos) {
        _toastErr('You can add up to $_maxVideos videos.');
        return;
      }
      final x = await _picker.pickVideo(
        source: source,
        maxDuration: const Duration(minutes: 2),
      );
      if (x == null) return;
      final length = await File(x.path).length();
      if (length > _maxVideoBytes) {
        _toastErr('That video is too large. Choose one under 40 MB.');
        return;
      }
      if (!mounted) return;
      setState(() {
        _videos.add(
          LocalMedia(
            bytes: Uint8List(0),
            filename: x.name.isEmpty ? 'video.mp4' : x.name,
            mime: lookupMimeType(x.name) ?? 'video/mp4',
            isVideo: true,
            filePath: x.path,
          ),
        );
      });
    } catch (e) {
      debugPrint('Pick listing video error: $e');
      if (!mounted) return;
      _toastErr('Could not add that video. Please try again.');
    }
  }

  Future<List<String>> _uploadListingVideos(
    MarketplaceService svc,
    String? uploadToken,
  ) async {
    final urls = <String>[];
    final uid = (_auth.currentUser?.uid ?? _uid).trim();
    for (var i = 0; i < _videos.length; i++) {
      final video = _videos[i];
      final path = (video.filePath ?? '').trim();
      final String url;
      if (path.isNotEmpty && uid.isNotEmpty) {
        final ext = video.filename.contains('.')
            ? video.filename.split('.').last.toLowerCase()
            : 'mp4';
        final safeExt = ext.length > 4 ? 'mp4' : ext;
        final ref = FirebaseStorage.instance.ref().child(
          'profile_photos/${uid}_listingvideo_${DateTime.now().millisecondsSinceEpoch}_$i.$safeExt',
        );
        await ref.putFile(
          File(path),
          SettableMetadata(contentType: video.mime ?? 'video/mp4'),
        );
        url = await ref.getDownloadURL();
      } else {
        url = await svc.uploadBytes(
          video.bytes,
          filename: video.filename.isNotEmpty ? video.filename : 'video_$i.mp4',
          mimeType: video.mime ?? 'video/mp4',
          token: uploadToken,
          timeout: const Duration(seconds: 90),
        );
      }
      if (url.trim().isNotEmpty) urls.add(url.trim());
    }
    if (urls.isEmpty) {
      throw StateError('Video upload failed. Check your connection and try again.');
    }
    return urls;
  }

  Future<void> _pickMorePhotosFromCamera() async {
    try {
      if (_gallery.length >= _maxGalleryPhotos) {
        _toastErr('You can add up to $_maxGalleryPhotos photos.');
        return;
      }
      final x = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
        maxWidth: 1600,
      );
      if (x == null) return;
      final bytes = await x.readAsBytes();
      setState(() {
        _gallery.add(
          LocalMedia(
            bytes: bytes,
            filename: x.name,
            mime: lookupMimeType(x.name, headerBytes: bytes),
          ),
        );
      });
    } catch (e) {
      debugPrint('Pick from camera error: $e');
      if (!mounted) return;
      _toastErr('Could not take photo. Please try again.');
    }
  }

  // ----------------- Bottom nav -----------------
  Widget _buildMerchantNavBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey[200]!)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 16,
              offset: const Offset(0, -6))
        ],
      ),
      child: SafeArea(
        child: SizedBox(
          height: 72,
          child: Row(
            children: [
              Expanded(child: _buildNavItem(Icons.home_rounded, 'Home', 0)),
              Expanded(
                  child: _buildNavItem(
                      Icons.storefront_rounded, 'Marketplace', 1)),
              Expanded(
                  child: _buildNavItem(
                      Icons.shopping_cart_rounded, 'Cart', 2)),
              Expanded(
                  child: _buildNavItem(Icons.message_rounded, 'Messages', 3)),
              Expanded(
                  child: _buildNavItem(
                      Icons.dashboard_rounded, 'Dashboard', 4)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, int index) {
    final isSelected = _selectedIndex == index;
    final sw = MediaQuery.sizeOf(context).width;
    final narrow = sw < 400;
    final hPad = narrow ? 2.0 : 5.0;
    final iconSize = narrow ? 22.0 : 24.0;
    final fontSize = narrow ? 10.0 : 12.0;

    return GestureDetector(
      onTap: () => _onItemTapped(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: hPad, vertical: narrow ? 8 : 10),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color:
              isSelected ? _brandOrange.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                color: isSelected ? _brandOrange : Colors.grey[600],
                size: iconSize),
            SizedBox(height: narrow ? 2 : 4),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: fontSize,
                color: isSelected ? _brandOrange : Colors.grey[600],
                fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
} // G?? END of _MarketplaceMerchantDashboardState

// ----------------- Quick action tile -----------------
class _QuickActionTile extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  /// When set, shows unread count from [NotificationStore] and clears on tap.
  final String? badgeRoute;

  const _QuickActionTile({
    required this.title,
    required this.icon,
    required this.onTap,
    required this.color,
    this.badgeRoute,
  });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: NotificationStore.instance,
      builder: (context, _) {
        final n = badgeRoute == null
            ? 0
            : NotificationStore.instance.unreadCountForBadgeRoute(badgeRoute!);
        return Material(
          color: Colors.white,
          elevation: 0,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () {
              if (badgeRoute != null) {
                unawaited(
                  NotificationStore.instance.markBadgeRouteAsRead(badgeRoute!),
                );
              }
              onTap();
            },
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  height: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(icon, color: color),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          title,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const Icon(Icons.chevron_right, color: Colors.black38),
                    ],
                  ),
                ),
                if (n > 0)
                  Positioned(
                    right: 6,
                    top: 4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red.shade700,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.12),
                            blurRadius: 4,
                            offset: const Offset(0, 1),
                          ),
                        ],
                      ),
                      constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                      child: Text(
                        n > 99 ? '99+' : '$n',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          height: 1.1,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ----------------- Skeletons -----------------
class _DashboardSkeleton extends StatelessWidget {
  const _DashboardSkeleton();

  @override
  Widget build(BuildContext context) {
    Widget box(double h, {double? w}) => Container(
          height: h,
          width: w ?? double.infinity,
          decoration: BoxDecoration(
            color: const Color(0xFFEDEFF3),
            borderRadius: BorderRadius.circular(16),
          ),
        );

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            height: 120,
            decoration: BoxDecoration(
              color: const Color(0xFFEDEFF3),
              borderRadius: BorderRadius.circular(22),
            ),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: box(74)),
            const SizedBox(width: 12),
            Expanded(child: box(74))
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: box(74)),
            const SizedBox(width: 12),
            Expanded(child: box(74))
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: box(74)),
            const SizedBox(width: 12),
            Expanded(child: box(74))
          ]),
          const SizedBox(height: 12),
          box(90),
          const SizedBox(height: 12),
          box(110),
          const SizedBox(height: 12),
          const _ItemsGridSkeleton(count: 6),
        ],
      ),
    );
  }
}

class _ItemsGridSkeleton extends StatelessWidget {
  final int count;
  const _ItemsGridSkeleton({required this.count});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      primary: false,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: count,
      gridDelegate: _merchantItemsGridDelegate(context),
      itemBuilder: (_, __) => Container(
        decoration: BoxDecoration(
          color: const Color(0xFFEDEFF3),
          borderRadius: BorderRadius.circular(18),
        ),
      ),
    );
  }
}

// ----------------- Cards -----------------

/// Firestore `marketplace_items` may use `image` (base64), `imageUrl` (upload flow),
/// or only `gallery` / `galleryUrls` G?? same as [main_marketPlace] / MerchantProductsPage.
String? _coverImageSourceFromItem(Map<String, dynamic> item) {
  String? take(dynamic v) {
    final t = (v ?? '').toString().trim();
    return t.isEmpty ? null : t;
  }

  final direct = take(item['imageUrl']) ??
      take(item['image']) ??
      take(item['photo']) ??
      take(item['picture']);
  if (direct != null) return direct;

  final urls = item['galleryUrls'];
  if (urls is List) {
    for (final e in urls) {
      final u = e.toString().trim();
      if (u.isNotEmpty) return u;
    }
  }
  final gal = item['gallery'];
  if (gal is List) {
    for (final e in gal) {
      final u = e.toString().trim();
      if (u.isNotEmpty) return u;
    }
  }
  return null;
}

class _ModernItemMiniCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final bool busy;
  final VoidCallback? onPromote;

  const _ModernItemMiniCard({
    required this.item,
    this.busy = false,
    this.onPromote,
  });

  @override
  Widget build(BuildContext context) {
    final statusLabel = _MarketplaceMerchantDashboardState._reviewLabel(item);
    final statusColor = _MarketplaceMerchantDashboardState._reviewColor(item);
    final sold = _MarketplaceMerchantDashboardState._itemIsSold(item);
    final canPromote =
        _MarketplaceMerchantDashboardState._itemReviewStatus(item) ==
                'approved' &&
            item['isActive'] == true &&
            !sold;
    final isBoosted = MarketplacePromoteService.isPromotedNow(item);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      clipBehavior: Clip.antiAlias,
      child: LayoutBuilder(
        builder: (context, c) {
          final narrow = c.maxWidth < 168;
          final padH = narrow ? 8.0 : 10.0;
          final padV = narrow ? 5.0 : 7.0;

          return Stack(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    flex: 5,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        ColorFiltered(
                          colorFilter: sold
                              ? const ColorFilter.mode(
                                  Color(0x88000000), BlendMode.darken)
                              : const ColorFilter.mode(
                                  Colors.transparent, BlendMode.srcOver),
                          child: _ImageAny(_coverImageSourceFromItem(item)),
                        ),
                        if (sold) const _SoldDiagonalBanner(),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 5,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(padH, padV, padH, padV),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (item['name'] ?? 'Unknown').toString(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: narrow ? 12.0 : 13.5,
                              height: 1.15,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            mwkBuyer(item['price']),
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: Colors.green,
                              fontSize: narrow ? 11.5 : 13.0,
                              height: 1.15,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Icon(Icons.circle,
                                  size: narrow ? 8 : 10, color: statusColor),
                              SizedBox(width: narrow ? 4 : 6),
                              Flexible(
                                child: Text(
                                  statusLabel,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: Colors.black54,
                                    fontSize: narrow ? 10.5 : 12,
                                    height: 1.15,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Spacer(),
                          // Promote action below item details
                          SizedBox(
                            width: double.infinity,
                            height: narrow ? 28 : 30,
                            child: Material(
                              color: canPromote
                                  ? const Color(0xFFFF8A00)
                                  : const Color(0xFFE5E7EB),
                              borderRadius: BorderRadius.circular(10),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(10),
                                onTap: (!busy &&
                                        canPromote &&
                                        onPromote != null)
                                    ? onPromote
                                    : () {
                                        if (onPromote != null) onPromote!();
                                      },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.campaign_rounded,
                                      size: narrow ? 14 : 16,
                                      color: canPromote
                                          ? Colors.white
                                          : Colors.black45,
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      isBoosted ? 'Boosted' : 'Promote',
                                      style: TextStyle(
                                        color: canPromote
                                            ? Colors.white
                                            : Colors.black45,
                                        fontWeight: FontWeight.w900,
                                        fontSize: narrow ? 11 : 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              if (isBoosted)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: narrow ? 8 : 10,
                      vertical: narrow ? 3 : 4,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF8A00),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'Promoted',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: narrow ? 10 : 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _ItemCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final bool busy;
  final VoidCallback onDelete;
  final VoidCallback onEdit;
  final VoidCallback? onPromote;

  const _ItemCard({
    required this.item,
    required this.busy,
    required this.onDelete,
    required this.onEdit,
    this.onPromote,
  });

  @override
  Widget build(BuildContext context) {
    final statusLabel = _MarketplaceMerchantDashboardState._reviewLabel(item);
    final statusColor = _MarketplaceMerchantDashboardState._reviewColor(item);
    final isRejected =
        _MarketplaceMerchantDashboardState._itemReviewStatus(item) ==
            'rejected';
    final rejectReason = (item['rejectedReason'] ?? '').toString().trim();
    final showRejectReason = isRejected && rejectReason.isNotEmpty;
    final sold = _MarketplaceMerchantDashboardState._itemIsSold(item);
    final canPromote =
        _MarketplaceMerchantDashboardState._itemReviewStatus(item) ==
                'approved' &&
            item['isActive'] == true &&
            !sold;
    final isBoosted = MarketplacePromoteService.isPromotedNow(item);

    // Flex layout: image shrinks; text never overflows the grid cell.
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onEdit,
        child: LayoutBuilder(
          builder: (context, c) {
            final narrow = c.maxWidth < 168;
            final padH = narrow ? 6.0 : 8.0;
            final padV = narrow ? 4.0 : 5.0;
            final nameSize = narrow ? 11.5 : 13.0;
            final priceSize = narrow ? 11.0 : 12.5;
            final metaSize = narrow ? 10.0 : 11.5;
            final reasonSize = narrow ? 9.0 : 10.0;

            return Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: showRejectReason ? 5 : 6,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          ColorFiltered(
                            colorFilter: sold
                                ? const ColorFilter.mode(
                                    Color(0x88000000), BlendMode.darken)
                                : const ColorFilter.mode(
                                    Colors.transparent, BlendMode.srcOver),
                            child: _ImageAny(_coverImageSourceFromItem(item)),
                          ),
                          if (sold) const _SoldDiagonalBanner(),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: showRejectReason ? 5 : 4,
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(padH, padV, padH, padV),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: LayoutBuilder(
                                builder: (context, textConstraints) {
                                  return FittedBox(
                                    fit: BoxFit.scaleDown,
                                    alignment: Alignment.topLeft,
                                    child: ConstrainedBox(
                                      constraints: BoxConstraints(
                                        maxWidth: textConstraints.maxWidth,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            (item['name'] ?? 'Unknown')
                                                .toString(),
                                            style: TextStyle(
                                              fontWeight: FontWeight.w900,
                                              fontSize: nameSize,
                                              height: 1.1,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 1),
                                          Text(
                                            mwkBuyer(item['price']),
                                            style: TextStyle(
                                              fontWeight: FontWeight.w900,
                                              color: Colors.green,
                                              fontSize: priceSize,
                                              height: 1.1,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 1),
                                          Text(
                                            (item['category'] ?? 'other')
                                                .toString(),
                                            style: TextStyle(
                                              color: Colors.black54,
                                              fontWeight: FontWeight.w800,
                                              fontSize: metaSize,
                                              height: 1.1,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          if (showRejectReason) ...[
                                            const SizedBox(height: 1),
                                            Text(
                                              rejectReason,
                                              style: TextStyle(
                                                color: Colors.red.shade700,
                                                fontWeight: FontWeight.w700,
                                                fontSize: reasonSize,
                                                height: 1.1,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(height: 2),
                            SizedBox(
                              height: 28,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  if (canPromote && onPromote != null) ...[
                                    _iconBtn(
                                      icon: Icons.campaign_rounded,
                                      color: const Color(0xFFFF8A00),
                                      onTap: busy ? null : onPromote,
                                      compact: true,
                                    ),
                                    const SizedBox(width: 10),
                                  ],
                                  _iconBtn(
                                    icon: Icons.edit,
                                    color: const Color(0xFF16284C),
                                    onTap: onEdit,
                                    compact: true,
                                  ),
                                  const SizedBox(width: 10),
                                _iconBtn(
                                    icon: Icons.delete,
                                    color: Colors.red,
                                    onTap: busy ? null : onDelete,
                                    compact: true,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Positioned(
                  top: 8,
                  left: 8,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: narrow ? 8 : 10,
                          vertical: narrow ? 4 : 5,
                        ),
                        decoration: BoxDecoration(
                          color: statusColor,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          statusLabel,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: narrow ? 10.5 : 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      if (isBoosted) ...[
                        const SizedBox(height: 4),
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: narrow ? 8 : 10,
                            vertical: narrow ? 3 : 4,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF8A00),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            'Promoted',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: narrow ? 10 : 11,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  static Widget _iconBtn({
    required IconData icon,
    required Color color,
    required VoidCallback? onTap,
    bool compact = false,
  }) {
    final size = compact ? 26.0 : 30.0;
    return SizedBox(
      width: size,
      height: size,
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(
          side: BorderSide(color: Colors.black12),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          customBorder: const CircleBorder(),
          child: Icon(icon, size: compact ? 14 : 16, color: color),
        ),
      ),
    );
  }
}

/// Red diagonal SOLD band across a listing photo.
class _SoldDiagonalBanner extends StatelessWidget {
  const _SoldDiagonalBanner();

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: -34,
      top: 18,
      child: Transform.rotate(
        angle: 0.6,
        child: Container(
          width: 120,
          padding: const EdgeInsets.symmetric(vertical: 5),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFD32F2F), Color(0xFFB71C1C)],
            ),
            boxShadow: [
              BoxShadow(color: Color(0x66B71C1C), blurRadius: 8),
            ],
          ),
          alignment: Alignment.center,
          child: const Text(
            'SOLD',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              letterSpacing: 1.4,
            ),
          ),
        ),
      ),
    );
  }
}

// Image widget: supports http(s), data:image, or raw base64 ? decode-capped for low RAM.
class _ImageAny extends StatelessWidget {
  final dynamic imageData;
  const _ImageAny(this.imageData);

  @override
  Widget build(BuildContext context) {
    return VeroThumbImage(
      imageData,
      decodeLogicalPx: 360,
    );
  }
}

/// Owns [TextEditingController] for the business-description editor sheet.
class _BusinessDescriptionSheet extends StatefulWidget {
  const _BusinessDescriptionSheet({
    required this.initialText,
    required this.maxLength,
    required this.brandColor,
  });

  final String initialText;
  final int maxLength;
  final Color brandColor;

  @override
  State<_BusinessDescriptionSheet> createState() =>
      _BusinessDescriptionSheetState();
}

class _BusinessDescriptionSheetState extends State<_BusinessDescriptionSheet> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialText);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: 16 + bottomInset,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Business description',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              'Short blurb customers see on your shop and product pages '
              '(max ${widget.maxLength} characters).',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              maxLength: widget.maxLength,
              maxLines: 3,
              minLines: 2,
              autofocus: true,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) =>
                  Navigator.pop(context, _controller.text.trim()),
              decoration: InputDecoration(
                hintText: 'e.g. Fresh produce & household goods in Lilongwe',
                filled: true,
                fillColor: const Color(0xFFF4F6FA),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                counterStyle: TextStyle(
                  color: Colors.grey.shade600,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: widget.brandColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              onPressed: () =>
                  Navigator.pop(context, _controller.text.trim()),
              child: const Text(
                'Save',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _ShopHoursSheet extends StatefulWidget {
  const _ShopHoursSheet({
    required this.initialOpen,
    required this.initialClose,
    required this.initialDays,
    required this.brandColor,
  });

  final TimeOfDay initialOpen;
  final TimeOfDay initialClose;
  final Set<int> initialDays;
  final Color brandColor;

  @override
  State<_ShopHoursSheet> createState() => _ShopHoursSheetState();
}

class _ShopHoursSheetState extends State<_ShopHoursSheet> {
  static const _labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  late TimeOfDay _open;
  late TimeOfDay _close;
  late Set<int> _days;

  @override
  void initState() {
    super.initState();
    _open = widget.initialOpen;
    _close = widget.initialClose;
    _days = Set<int>.from(widget.initialDays);
    if (_days.isEmpty) {
      _days = {1, 2, 3, 4, 5, 6, 7};
    }
  }

  String _fmt(TimeOfDay t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  Future<void> _pickOpen() async {
    final t = await showTimePicker(context: context, initialTime: _open);
    if (t != null) setState(() => _open = t);
  }

  Future<void> _pickClose() async {
    final t = await showTimePicker(context: context, initialTime: _close);
    if (t != null) setState(() => _close = t);
  }

  void _toggleDay(int day) {
    setState(() {
      if (_days.contains(day)) {
        if (_days.length > 1) _days.remove(day);
      } else {
        _days.add(day);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final narrow = MediaQuery.sizeOf(context).width < 360;
    final openBtn = OutlinedButton.icon(
      onPressed: _pickOpen,
      icon: const Icon(Icons.wb_sunny_outlined, size: 18),
      label: Text(
        'Open ${_fmt(_open)}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
    final closeBtn = OutlinedButton.icon(
      onPressed: _pickClose,
      icon: const Icon(Icons.nights_stay_outlined, size: 18),
      label: Text(
        'Close ${_fmt(_close)}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: 16 + bottomInset,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Shop hours',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              'Customers see OPEN or CLOSED based on these days and times.',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Open days',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (var i = 1; i <= 7; i++)
                  FilterChip(
                    label: Text(
                      _labels[i - 1],
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        color: _days.contains(i)
                            ? Colors.white
                            : Colors.grey.shade800,
                      ),
                    ),
                    selected: _days.contains(i),
                    onSelected: (_) => _toggleDay(i),
                    selectedColor: widget.brandColor,
                    checkmarkColor: Colors.white,
                    backgroundColor: const Color(0xFFF4F6FA),
                    side: BorderSide(
                      color: _days.contains(i)
                          ? widget.brandColor
                          : Colors.grey.shade300,
                    ),
                    showCheckmark: false,
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                onPressed: () => setState(() => _days = {1, 2, 3, 4, 5, 6, 7}),
                child: Text(
                  'Every day',
                  style: TextStyle(
                    color: widget.brandColor,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            if (narrow) ...[
              openBtn,
              const SizedBox(height: 10),
              closeBtn,
            ] else
              Row(
                children: [
                  Expanded(child: openBtn),
                  const SizedBox(width: 10),
                  Expanded(child: closeBtn),
                ],
              ),
            const SizedBox(height: 16),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: widget.brandColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              onPressed: () => Navigator.pop(
                context,
                (open: _open, close: _close, days: Set<int>.from(_days)),
              ),
              child: const Text(
                'Save hours',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _MarketplaceBusinessNameSheet extends StatefulWidget {
  const _MarketplaceBusinessNameSheet({
    required this.initialText,
    required this.brandColor,
  });

  final String initialText;
  final Color brandColor;

  @override
  State<_MarketplaceBusinessNameSheet> createState() =>
      _MarketplaceBusinessNameSheetState();
}

class _MarketplaceBusinessNameSheetState
    extends State<_MarketplaceBusinessNameSheet> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialText);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: 16 + bottomInset,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Business name',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              'This name appears on your shop and product listings.',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              maxLength: 80,
              autofocus: true,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) =>
                  Navigator.pop(context, _controller.text.trim()),
              decoration: InputDecoration(
                hintText: 'e.g. FreshMart Lilongwe',
                filled: true,
                fillColor: const Color(0xFFF4F6FA),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: widget.brandColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              onPressed: () =>
                  Navigator.pop(context, _controller.text.trim()),
              child: const Text(
                'Save name',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _MarketplacePhoneSheet extends StatefulWidget {
  const _MarketplacePhoneSheet({
    required this.initialPhone,
    required this.brandColor,
  });

  final String initialPhone;
  final Color brandColor;

  @override
  State<_MarketplacePhoneSheet> createState() => _MarketplacePhoneSheetState();
}

class _MarketplacePhoneSheetState extends State<_MarketplacePhoneSheet> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialPhone);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: 16 + bottomInset,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Phone number',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              'Customers can reach you on this number.',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              keyboardType: TextInputType.phone,
              autofocus: true,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) =>
                  Navigator.pop(context, _controller.text.trim()),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[0-9+\s-]')),
              ],
              decoration: InputDecoration(
                hintText: 'e.g. +265 99 123 4567',
                filled: true,
                fillColor: const Color(0xFFF4F6FA),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 14),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: widget.brandColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              onPressed: () => Navigator.pop(context, _controller.text.trim()),
              child: const Text(
                'Save phone',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

/// Isolate entry for marketplace upload compression (must be top-level).
Uint8List _compressMarketplaceBytesIsolate(Uint8List raw) {
  try {
    final decoded = img.decodeImage(raw);
    if (decoded == null) return raw;
    const maxSide = 1280;
    var im = decoded;
    if (im.width > maxSide || im.height > maxSide) {
      if (im.width >= im.height) {
        im = img.copyResize(
          im,
          width: maxSide,
          interpolation: img.Interpolation.linear,
        );
      } else {
        im = img.copyResize(
          im,
          height: maxSide,
          interpolation: img.Interpolation.linear,
        );
      }
    }
    final out = Uint8List.fromList(img.encodeJpg(im, quality: 72));
    return out.lengthInBytes > 0 && out.lengthInBytes < raw.lengthInBytes
        ? out
        : raw;
  } catch (_) {
    return raw;
  }
}
